import React, { useEffect, useState } from "react";
import axios from "axios";
import { Megaphone, X, AlertTriangle, CheckCircle2, AlertCircle } from "lucide-react";

// ============================================
// AstroWax Panel — Announcement Banner
// Shows active, admin-posted announcements to every logged-in user.
// Dismissals are remembered per-browser so a banner doesn't keep
// reappearing once the user has read it (it comes back if the admin
// edits it again, since editing changes updatedAt).
// ============================================

const DISMISS_KEY = "aw_dismissed_announcements";

function getDismissed(): Record<string, string> {
  try {
    return JSON.parse(localStorage.getItem(DISMISS_KEY) || "{}");
  } catch {
    return {};
  }
}

function severityStyle(severity: string) {
  switch (severity) {
    case "critical":
      return { bg: "rgba(239,68,68,.1)", border: "rgba(239,68,68,.35)", color: "#f87171", Icon: AlertCircle };
    case "warning":
      return { bg: "rgba(245,158,11,.1)", border: "rgba(245,158,11,.35)", color: "#fbbf24", Icon: AlertTriangle };
    case "success":
      return { bg: "rgba(16,185,129,.1)", border: "rgba(16,185,129,.35)", color: "#34d399", Icon: CheckCircle2 };
    default:
      return { bg: "rgba(168,85,247,.1)", border: "rgba(168,85,247,.35)", color: "#c084fc", Icon: Megaphone };
  }
}

export function AnnouncementBanner() {
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [dismissed, setDismissed] = useState<Record<string, string>>(getDismissed());

  const load = () => {
    axios.get("/api/announcements").then(res => {
      setAnnouncements(Array.isArray(res.data) ? res.data : []);
    }).catch(() => {});
  };

  useEffect(() => {
    load();
    const interval = setInterval(load, 60000);
    return () => clearInterval(interval);
  }, []);

  const dismiss = (a: any) => {
    const next = { ...dismissed, [a.id]: a.updatedAt || a.createdAt };
    setDismissed(next);
    try { localStorage.setItem(DISMISS_KEY, JSON.stringify(next)); } catch {}
  };

  const visible = announcements.filter(a => dismissed[a.id] !== (a.updatedAt || a.createdAt));

  if (visible.length === 0) return null;

  return (
    <div className="flex flex-col gap-2 px-4 sm:px-6 md:px-8 pt-4">
      {visible.map(a => {
        const s = severityStyle(a.severity);
        const Icon = s.Icon;
        return (
          <div
            key={a.id}
            className="flex items-start gap-3 rounded-2xl p-4"
            style={{ background: s.bg, border: `1px solid ${s.border}` }}
          >
            <Icon className="w-4 h-4 mt-0.5 flex-shrink-0" style={{ color: s.color }} />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold" style={{ color: s.color }}>{a.title}</p>
              <p className="text-xs text-zinc-300/90 mt-0.5 whitespace-pre-wrap">{a.message}</p>
            </div>
            <button
              onClick={() => dismiss(a)}
              className="flex-shrink-0 p-1 rounded-lg hover:bg-white/10 transition-colors"
              aria-label="Dismiss"
            >
              <X className="w-3.5 h-3.5 text-zinc-400" />
            </button>
          </div>
        );
      })}
    </div>
  );
}

export default AnnouncementBanner;

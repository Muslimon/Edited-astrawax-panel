// @ts-nocheck
import AdminControls from '../components/AdminControls';
import React, { useEffect, useState, useRef } from "react";
import axios from "axios";
import { useAuth } from "../context/AuthContext";
import { useSettings } from "../context/SettingsContext";
import { motion } from "framer-motion";
import {
  Check, User, Trash2, Layout, Upload, RefreshCw, Key,
  CheckCircle2, AlertCircle, ExternalLink, Cpu,
  Image as ImageIcon, Settings, ArrowLeft, Menu, X,
  Lock, Sparkles, Hexagon, Palette, Megaphone, SlidersHorizontal, Egg, Ban, Pencil
} from "lucide-react";
import { Link } from "react-router-dom";
import { ImageCropper } from "../components/ImageCropper";
import { LoadingOverlay } from "../components/LoadingOverlay";
import { initializeApp, deleteApp, getApps } from "firebase/app";

// ============================================
// AstroWax Panel V1.80 — Admin Settings
// Glass + Purple Theme + 5 Premium Accents
// ============================================

const PREMIUM_THEMES = [
  {
    id: "purple",
    name: "AstroWax",
    gradient: "linear-gradient(135deg, #a855f7, #7e22ce)",
    glow: "rgba(168, 85, 247, 0.7)",
  },
  {
    id: "blue",
    name: "Cyber",
    gradient: "linear-gradient(135deg, #3b82f6, #1d4ed8)",
    glow: "rgba(59, 130, 246, 0.7)",
  },
  {
    id: "emerald",
    name: "Emerald",
    gradient: "linear-gradient(135deg, #10b981, #047857)",
    glow: "rgba(16, 185, 129, 0.7)",
  },
  {
    id: "orange",
    name: "Sunset",
    gradient: "linear-gradient(135deg, #f97316, #c2410c)",
    glow: "rgba(249, 115, 22, 0.7)",
  },
  {
    id: "rose",
    name: "Rose",
    gradient: "linear-gradient(135deg, #f43f5e, #be123c)",
    glow: "rgba(244, 63, 94, 0.7)",
  },
];

const WALLPAPER_PRESETS = [
  {
    name: "PlayStation Blue",
    url: "https://4kwallpapers.com/images/walls/thumbs_2t/24671.jpg",
  },
  {
    name: "Modern 11",
    url: "https://4kwallpapers.com/images/walls/thumbs_2t/6753.jpg",
  },
  {
    name: "ASUS ROG City",
    url: "https://4kwallpapers.com/images/walls/thumbs_2t/11603.jpg",
  },
  {
    name: "Xbox Pride",
    url: "https://4kwallpapers.com/images/walls/thumbs_2t/20829.jpg",
  },
  {
    name: "Minecraft Copper Age",
    url: "https://4kwallpapers.com/images/walls/thumbs_2t/24242.jpg",
  },
];

export default function AdminSettingsPage(): React.ReactElement {
  const [activeTab, setActiveTab] = useState("branding");
  const [mobileOpen, setMobileOpen] = useState(false);

  const adminTabs = [
    { id: "branding", label: "Branding", icon: <Layout size={20} /> },
    { id: "features", label: "Features", icon: <Settings size={20} /> },
    { id: "runtime", label: "Runtime", icon: <Cpu size={20} /> },
    { id: "appearance", label: "Appearance", icon: <ImageIcon size={20} /> },
    { id: "auth", label: "Authentication", icon: <Key size={20} /> },
    { id: "users", label: "Users", icon: <User size={20} /> },
    { id: "announcements", label: "Announcements", icon: <Megaphone size={20} /> },
    { id: "limits", label: "Server Limits", icon: <SlidersHorizontal size={20} /> },
    { id: "eggs", label: "Eggs", icon: <Egg size={20} /> },
    { id: "system", label: "System", icon: <RefreshCw size={20} /> },
  ];

  const scrollToTab = (id: string) => {
    setActiveTab(id);
    setMobileOpen(false);
    const element = document.getElementById(id);
    if (element) element.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) setActiveTab(entry.target.id);
        });
      },
      { root: document.getElementById("settings-scroll-container"), rootMargin: "-10% 0px -60% 0px", threshold: 0 }
    );
    adminTabs.forEach((tab) => {
      const el = document.getElementById(tab.id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, []);

  const { user, logout, updateUser } = useAuth();
  const {
    panelName, panelLogo, panelBackgroundImage, panelBackgroundBlur,
    enablePlayit, enableTutorial, enableLoginAnimation, enableRegistration,
    theme, setTheme,
    enableGoogleLogin, firebaseApiKey, firebaseAuthDomain, firebaseProjectId,
    firebaseStorageBucket, firebaseMessagingSenderId, firebaseAppId,
    defaultRuntime, setDefaultRuntime,
    isDevPanel, fetchSettings
  } = useSettings();

  const [users, setUsers] = useState<any[]>([]);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("user");

  const [newCustomUsername, setNewCustomUsername] = useState(user?.username || "");
  const [isChangingUsername, setIsChangingUsername] = useState(false);
  const [usernameMsg, setUsernameMsg] = useState<{ text: string; type: "success" | "error" } | null>(null);

  useEffect(() => {
    if (user?.username) setNewCustomUsername(user.username);
  }, [user?.username]);

  const handleChangeUsername = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustomUsername || newCustomUsername.trim().length < 3) {
      setUsernameMsg({ text: "Username must be at least 3 characters", type: "error" });
      return;
    }
    setIsChangingUsername(true);
    setUsernameMsg(null);
    try {
      const res = await axios.put("/api/auth/username", { newUsername: newCustomUsername.trim() });
      if (updateUser) updateUser({ username: res.data.username });
      setUsernameMsg({ text: "Username updated successfully!", type: "success" });
      if (user.role === "admin" || user.role === "owner") fetchUsers();
    } catch (err: any) {
      setUsernameMsg({ text: err.response?.data?.error || "Failed to update username", type: "error" });
    } finally {
      setIsChangingUsername(false);
    }
  };

  const [newPanelName, setNewPanelName] = useState(panelName);
  const [newEnablePlayit, setNewEnablePlayit] = useState(enablePlayit);
  const [newEnableTutorial, setNewEnableTutorial] = useState(enableTutorial);
  const [newEnableLoginAnimation, setNewEnableLoginAnimation] = useState(enableLoginAnimation);
  const [newEnableRegistration, setNewEnableRegistration] = useState(enableRegistration);
  const [newTheme, setNewTheme] = useState(theme || 'purple');
  const [newDefaultRuntime, setNewDefaultRuntime] = useState(defaultRuntime || 'docker');
  const [isUpdatingRuntime, setIsUpdatingRuntime] = useState(false);
  const [runtimeStatusMsg, setRuntimeStatusMsg] = useState<{ text: string; type: "success" | "error" | "warning" } | null>(null);

  const [fbEnableGoogleLogin, setFbEnableGoogleLogin] = useState<boolean>(enableGoogleLogin || false);
  const [fbApiKey, setFbApiKey] = useState<string>(firebaseApiKey || "");
  const [fbAuthDomain, setFbAuthDomain] = useState<string>(firebaseAuthDomain || "");
  const [fbProjectId, setFbProjectId] = useState<string>(firebaseProjectId || "");
  const [fbStorageBucket, setFbStorageBucket] = useState<string>(firebaseStorageBucket || "");
  const [fbMessagingSenderId, setFbMessagingSenderId] = useState<string>(firebaseMessagingSenderId || "");
  const [fbAppId, setFbAppId] = useState<string>(firebaseAppId || "");
  const [isSavingFirebase, setIsSavingFirebase] = useState(false);
  const [fbStatusMsg, setFbStatusMsg] = useState<{ text: string; type: "success" | "error" } | null>(null);

  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [croppingType, setCroppingType] = useState<"logo" | "background" | null>(null);
  const [bgAspectRatio, setBgAspectRatio] = useState<number>(16 / 9);
  const [tempBgBlur, setTempBgBlur] = useState<number>(10);
  const [customBgUrlInput, setCustomBgUrlInput] = useState<string>("");
  const bgFileInputRef = useRef<HTMLInputElement>(null);
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [adminUserNewPassword, setAdminUserNewPassword] = useState("");
  const [isCreatingUser, setIsCreatingUser] = useState(false);
  const [isUpdatingLogo, setIsUpdatingLogo] = useState(false);
  const [isSavingSettings, setIsSavingSettings] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isUpdatingSystem, setIsUpdatingSystem] = useState(false);
  const [updateCheckStatus, setUpdateCheckStatus] = useState<"idle" | "checking" | "up-to-date" | "error">("idle");

  // ============================================
  // ANNOUNCEMENTS — admin-only banner management
  // ============================================
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [isLoadingAnnouncements, setIsLoadingAnnouncements] = useState(false);
  const [announcementForm, setAnnouncementForm] = useState({ title: "", message: "", severity: "info", expiresAt: "" });
  const [editingAnnouncementId, setEditingAnnouncementId] = useState<string | null>(null);
  const [isSavingAnnouncement, setIsSavingAnnouncement] = useState(false);
  const [announcementMsg, setAnnouncementMsg] = useState<{ text: string; type: "success" | "error" } | null>(null);

  const fetchAnnouncements = async () => {
    setIsLoadingAnnouncements(true);
    try {
      const res = await axios.get("/api/admin/announcements");
      setAnnouncements(Array.isArray(res.data) ? res.data : []);
    } catch (err) {
      console.error("Failed to load announcements", err);
    } finally {
      setIsLoadingAnnouncements(false);
    }
  };

  useEffect(() => { fetchAnnouncements(); }, []);

  const resetAnnouncementForm = () => {
    setAnnouncementForm({ title: "", message: "", severity: "info", expiresAt: "" });
    setEditingAnnouncementId(null);
  };

  const startEditAnnouncement = (a: any) => {
    setEditingAnnouncementId(a.id);
    setAnnouncementForm({
      title: a.title || "",
      message: a.message || "",
      severity: a.severity || "info",
      expiresAt: a.expiresAt ? a.expiresAt.slice(0, 10) : "",
    });
  };

  const handleSaveAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!announcementForm.title.trim() || !announcementForm.message.trim()) {
      setAnnouncementMsg({ text: "Title and message are required", type: "error" });
      return;
    }
    setIsSavingAnnouncement(true);
    setAnnouncementMsg(null);
    try {
      const payload = {
        title: announcementForm.title.trim(),
        message: announcementForm.message.trim(),
        severity: announcementForm.severity,
        expiresAt: announcementForm.expiresAt || null,
      };
      if (editingAnnouncementId) {
        await axios.put(`/api/admin/announcements/${editingAnnouncementId}`, payload);
      } else {
        await axios.post("/api/admin/announcements", payload);
      }
      await fetchAnnouncements();
      resetAnnouncementForm();
      setAnnouncementMsg({ text: "Announcement saved", type: "success" });
    } catch (err: any) {
      setAnnouncementMsg({ text: err.response?.data?.error || "Failed to save announcement", type: "error" });
    } finally {
      setIsSavingAnnouncement(false);
    }
  };

  const toggleAnnouncementActive = async (a: any) => {
    try {
      await axios.put(`/api/admin/announcements/${a.id}`, { active: !a.active });
      fetchAnnouncements();
    } catch (err) {
      console.error("Failed to toggle announcement", err);
    }
  };

  const deleteAnnouncement = async (id: string) => {
    if (!window.confirm("Delete this announcement?")) return;
    try {
      await axios.delete(`/api/admin/announcements/${id}`);
      if (editingAnnouncementId === id) resetAnnouncementForm();
      fetchAnnouncements();
    } catch (err) {
      console.error("Failed to delete announcement", err);
    }
  };

  // ============================================
  // SERVER LIMITS — admin-configurable plan/cap for regular users
  // ============================================
  const [limitsForm, setLimitsForm] = useState({ ram: 4, cpu: 150, disk: 10, maxServers: 2, minPort: 1024 });
  const [isLoadingLimits, setIsLoadingLimits] = useState(false);
  const [isSavingLimits, setIsSavingLimits] = useState(false);
  const [limitsMsg, setLimitsMsg] = useState<{ text: string; type: "success" | "error" } | null>(null);

  useEffect(() => {
    (async () => {
      setIsLoadingLimits(true);
      try {
        const res = await axios.get("/api/admin/limits");
        setLimitsForm(res.data);
      } catch (err) {
        console.error("Failed to load server limits", err);
      } finally {
        setIsLoadingLimits(false);
      }
    })();
  }, []);

  const handleSaveLimits = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingLimits(true);
    setLimitsMsg(null);
    try {
      const res = await axios.put("/api/admin/limits", limitsForm);
      setLimitsForm(res.data);
      setLimitsMsg({ text: "Server limits updated for all regular users", type: "success" });
    } catch (err: any) {
      setLimitsMsg({ text: err.response?.data?.error || "Failed to update server limits", type: "error" });
    } finally {
      setIsSavingLimits(false);
    }
  };

  // ============================================
  // EGGS — ban/unban server software from the create-server picker
  // ============================================
  const [eggs, setEggs] = useState<any[]>([]);
  const [isLoadingEggs, setIsLoadingEggs] = useState(false);
  const [isSavingEggs, setIsSavingEggs] = useState(false);

  const fetchEggs = async () => {
    setIsLoadingEggs(true);
    try {
      const res = await axios.get("/api/admin/eggs");
      setEggs(Array.isArray(res.data?.eggs) ? res.data.eggs : []);
    } catch (err) {
      console.error("Failed to load eggs", err);
    } finally {
      setIsLoadingEggs(false);
    }
  };

  useEffect(() => { fetchEggs(); }, []);

  const toggleEgg = async (eggId: string, nextDisabled: boolean) => {
    const previous = eggs;
    // Optimistic update
    setEggs(prev => prev.map(e => e.id === eggId ? { ...e, disabled: nextDisabled } : e));
    setIsSavingEggs(true);
    try {
      const disabledIds = eggs.filter(e => (e.id === eggId ? nextDisabled : e.disabled)).map(e => e.id);
      const res = await axios.put("/api/admin/eggs", { disabled: disabledIds });
      setEggs(Array.isArray(res.data?.eggs) ? res.data.eggs : previous);
    } catch (err) {
      console.error("Failed to update egg", err);
      setEggs(previous);
    } finally {
      setIsSavingEggs(false);
    }
  };

  const fileInputRef = useRef<HTMLInputElement>(null);

  // ============================================
  // ✅ SYSTEM UPDATE — Check for latest version
  // ============================================
  const PANEL_VERSION = "1.80";
  const handleSystemUpdate = async () => {
    if (updateCheckStatus === "checking") return;
    setUpdateCheckStatus("checking");
    setIsUpdatingSystem(true);

    // Simulated update check with a smooth delay
    // (Replace this timeout with a real API call to /api/system/update-check when backend is ready)
    await new Promise((resolve) => setTimeout(resolve, 2600));

    setIsUpdatingSystem(false);
    setUpdateCheckStatus("up-to-date");
  };

  useEffect(() => {
    setNewPanelName(panelName);
    setNewEnablePlayit(enablePlayit);
    setNewEnableTutorial(enableTutorial);
    setNewEnableLoginAnimation(enableLoginAnimation);
    setNewEnableRegistration(enableRegistration);
    setNewTheme(theme || 'purple');
    setFbEnableGoogleLogin(enableGoogleLogin || false);
    setFbApiKey(firebaseApiKey || "");
    setFbAuthDomain(firebaseAuthDomain || "");
    setFbProjectId(firebaseProjectId || "");
    setFbStorageBucket(firebaseStorageBucket || "");
    setFbMessagingSenderId(firebaseMessagingSenderId || "");
    setFbAppId(firebaseAppId || "");
    setCustomBgUrlInput(panelBackgroundImage || "");
    setNewDefaultRuntime(defaultRuntime || 'docker');
  }, [defaultRuntime, panelName, panelBackgroundImage, enablePlayit, enableTutorial, enableLoginAnimation, enableRegistration, theme, enableGoogleLogin, firebaseApiKey, firebaseAuthDomain, firebaseProjectId, firebaseStorageBucket, firebaseMessagingSenderId, firebaseAppId]);

  const applyTheme = async (themeId: string) => {
    try {
      setNewTheme(themeId);
      setTheme(themeId);
      document.documentElement.setAttribute('data-theme', themeId);
      await axios.put("/api/system/settings", { theme: themeId });
      await fetchSettings();
    } catch (e) {
      console.error("Failed to apply theme", e);
    }
  };

  const handleSaveFirebaseSettings = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsSavingFirebase(true);
    setFbStatusMsg(null);
    try {
      await axios.put("/api/system/settings", {
        enableGoogleLogin: fbEnableGoogleLogin,
        firebaseApiKey: fbApiKey,
        firebaseAuthDomain: fbAuthDomain,
        firebaseProjectId: fbProjectId,
        firebaseStorageBucket: fbStorageBucket,
        firebaseMessagingSenderId: fbMessagingSenderId,
        firebaseAppId: fbAppId
      });
      await fetchSettings();
      setFbStatusMsg({ text: "Firebase & Google Login settings saved successfully!", type: "success" });
    } catch (err: any) {
      setFbStatusMsg({ text: err.response?.data?.error || "Failed to save Firebase config", type: "error" });
    } finally {
      setIsSavingFirebase(false);
    }
  };

  const handleTestFirebaseConfig = async () => {
    setFbStatusMsg(null);
    if (!fbApiKey || !fbProjectId) {
      setFbStatusMsg({ text: "Please enter at least API Key and Project ID to test.", type: "error" });
      return;
    }
    try {
      const testAppName = "test-fb-app-" + Date.now();
      const testApp = initializeApp({
        apiKey: fbApiKey,
        authDomain: fbAuthDomain,
        projectId: fbProjectId,
        storageBucket: fbStorageBucket,
        messagingSenderId: fbMessagingSenderId,
        appId: fbAppId
      }, testAppName);
      await deleteApp(testApp);
      setFbStatusMsg({ text: "Firebase Configuration verified valid!", type: "success" });
    } catch (err: any) {
      setFbStatusMsg({ text: "Firebase config error: " + (err.message || String(err)), type: "error" });
    }
  };

  const fetchUsers = async () => {
    if (user.role !== "admin" && user.role !== "owner") return;
    try {
      const res = await axios.get("/api/system/users");
      setUsers(res.data);
    } catch (e) { }
  };

  useEffect(() => {
    fetchUsers();
    if (panelBackgroundBlur !== undefined) setTempBgBlur(panelBackgroundBlur);
  }, [user]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, type: "logo" | "background" = "logo") => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.addEventListener('load', async () => {
        const base64 = reader.result?.toString() || null;
        if (base64) {
          if (type === "logo") {
            setSelectedImage(base64);
            setCroppingType(type);
          } else if (type === "background") {
            setIsProcessing(true);
            try {
              await axios.put("/api/system/settings", { panelBackgroundImage: base64 });
              await fetchSettings();
            } catch (err) {
              console.error(err);
            } finally {
              setIsProcessing(false);
            }
          }
        }
      });
      reader.readAsDataURL(file);
    }
    if (fileInputRef.current) fileInputRef.current.value = "";
    if (bgFileInputRef.current) bgFileInputRef.current.value = "";
  };

  const handleCropComplete = async (croppedImageBase64: string) => {
    const type = croppingType;
    setSelectedImage(null);
    setCroppingType(null);
    if (type === "logo") {
      setIsUpdatingLogo(true);
      try {
        await axios.put("/api/system/settings", { panelLogo: croppedImageBase64 });
        await fetchSettings();
      } catch (err: any) {
        alert(err.response?.data?.error || "Error updating logo");
      } finally {
        setIsUpdatingLogo(false);
      }
    } else if (type === "background") {
      setIsProcessing(true);
      try {
        await axios.put("/api/system/settings", { panelBackgroundImage: croppedImageBase64 });
        await fetchSettings();
      } catch (err: any) {
        alert(err.response?.data?.error || "Error updating background");
      } finally {
        setIsProcessing(false);
      }
    }
  };

  const createUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsCreatingUser(true);
    try {
      await axios.post("/api/system/users", { username, password, role });
      setUsername("");
      setPassword("");
      fetchUsers();
      alert("User created successfully");
    } catch (e: any) {
      alert(e.response?.data?.error || "Error creating user");
    } finally {
      setIsCreatingUser(false);
    }
  };

  const changeUserRole = async (id: string, newRole: string) => {
    try {
      await axios.put(`/api/system/users/${id}/role`, { newRole });
      fetchUsers();
    } catch (err: any) {
      console.error(err);
      alert(err.response?.data?.error || "Failed to change role");
    }
  };

  const changeUserPassword = async (id: string) => {
    try {
      if (adminUserNewPassword.length < 8) {
        alert("Password must be at least 8 characters");
        return;
      }
      await axios.put(`/api/system/users/${id}/password`, { newPassword: adminUserNewPassword });
      alert("Password changed successfully");
      setEditingUserId(null);
      setAdminUserNewPassword("");
      if (user.id === id) logout();
    } catch (e: any) {
      alert(e.response?.data?.error || "Error changing password");
    }
  };

  const deleteUser = async (id: string) => {
    try {
      await axios.delete(`/api/system/users/${id}`);
      fetchUsers();
    } catch (e) { }
  };

  const renderGoogleFirebase = () => (
    <div className="aw-glass p-6 md:p-8 mt-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 relative z-10 border-b border-purple-500/20 pb-6">
        <div>
          <h2 className="text-xl font-bold flex items-center text-purple-200">
            <Key className="mr-3 text-purple-400 w-6 h-6" /> Google & Firebase Authentication
          </h2>
          <p className="text-xs text-zinc-400 mt-1">
            Configure Firebase API Keys to enable 1-click Google Sign-In for admins and users.
          </p>
        </div>
        <div className="flex items-center gap-3 bg-black/40 p-2 rounded-xl border border-purple-500/25">
          <span className="text-xs font-semibold text-zinc-400">Enable Google Login:</span>
          <label className="relative inline-flex items-center cursor-pointer flex-shrink-0">
            <input
              type="checkbox"
              checked={fbEnableGoogleLogin}
              onChange={(e: any) => setFbEnableGoogleLogin(e.target.checked)}
              className="sr-only peer aw-toggle"
            />
            <div className="aw-toggle-track w-11 h-6 bg-zinc-800 border border-purple-500/20 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-zinc-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all"></div>
          </label>
        </div>
      </div>

      <div className="p-4 rounded-xl bg-purple-500/10 border border-purple-500/25 mb-6 text-xs text-purple-200/90 leading-relaxed">
        <div className="font-bold text-purple-300 text-sm mb-1 flex items-center gap-2">
          <Sparkles size={16} /> How to Setup Google Login in 1 Minute (No Code Needed!):
        </div>
        <ol className="list-decimal list-inside space-y-1 mt-2 text-zinc-400">
          <li>Open <a href="https://console.firebase.google.com" target="_blank" rel="noreferrer" className="text-purple-400 underline font-medium hover:text-purple-200 inline-flex items-center gap-1">Firebase Console <ExternalLink size={12} /></a> and create a free project.</li>
          <li>Go to <strong>Authentication → Sign-in method</strong> and enable <strong>Google</strong>.</li>
          <li>Under <strong>Settings → Authorized Domains</strong>, add your panel's domain or IP address.</li>
          <li>Go to <strong>Project Settings → General → Your apps</strong>, create a Web App and copy the Firebase config credentials below!</li>
        </ol>
      </div>

      {fbStatusMsg && (
        <div className={`p-4 rounded-xl mb-6 flex items-center gap-3 text-sm font-medium ${fbStatusMsg.type === "success" ? "bg-emerald-500/10 border border-emerald-500/30 text-emerald-400" : "bg-rose-500/10 border border-rose-500/30 text-rose-400"}`}>
          {fbStatusMsg.type === "success" ? <CheckCircle2 size={18} /> : <AlertCircle size={18} />}
          <span>{fbStatusMsg.text}</span>
        </div>
      )}

      <form onSubmit={handleSaveFirebaseSettings} className="space-y-4 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            { label: "Firebase API Key", value: fbApiKey, set: setFbApiKey, placeholder: "AIzaSy...", required: true },
            { label: "Auth Domain", value: fbAuthDomain, set: setFbAuthDomain, placeholder: "your-project.firebaseapp.com", required: true },
            { label: "Project ID", value: fbProjectId, set: setFbProjectId, placeholder: "your-project-id", required: true },
            { label: "Storage Bucket (Optional)", value: fbStorageBucket, set: setFbStorageBucket, placeholder: "your-project.appspot.com", required: false },
            { label: "Messaging Sender ID (Optional)", value: fbMessagingSenderId, set: setFbMessagingSenderId, placeholder: "1234567890", required: false },
            { label: "App ID (Optional)", value: fbAppId, set: setFbAppId, placeholder: "1:1234567890:web:abcdef", required: false },
          ].map((field) => (
            <div key={field.label}>
              <label className="block text-xs font-semibold text-purple-300 mb-1.5 uppercase tracking-wider">
                {field.label} {field.required && <span className="text-purple-400">*</span>}
              </label>
              <input
                type="text"
                placeholder={field.placeholder}
                value={field.value}
                onChange={(e: any) => field.set(e.target.value)}
                className="aw-input w-full rounded-xl px-4 py-2.5 text-sm font-mono"
              />
            </div>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-3 pt-4">
          <button
            type="submit"
            disabled={isSavingFirebase}
            className="aw-btn-primary px-6 py-2.5 rounded-xl font-bold disabled:opacity-50"
          >
            {isSavingFirebase ? "Saving Config..." : "Save Firebase Credentials"}
          </button>

          <button
            type="button"
            onClick={handleTestFirebaseConfig}
            className="aw-btn-ghost px-5 py-2.5 rounded-xl font-semibold"
          >
            Test Connection
          </button>
        </div>
      </form>
    </div>
  );

  if (!user || (user.role !== "admin" && user.role !== "owner")) {
    return (
      <div className="w-full flex items-center justify-center py-20 text-zinc-400">
        You do not have permission to view this page.
      </div>
    );
  }

  return (
    <>
      <style dangerouslySetInnerHTML={{__html: `
        .aw-glass {
          background: linear-gradient(135deg, rgba(20,12,35,.75), rgba(13,8,25,.9));
          backdrop-filter: blur(16px) saturate(1.4);
          -webkit-backdrop-filter: blur(16px) saturate(1.4);
          border: 1px solid rgba(168,85,247,.25);
          border-radius: 20px;
          position: relative;
          overflow: hidden;
          transition: all .3s cubic-bezier(.16,1,.3,1);
        }
        .aw-glass::before {
          content: '';
          position: absolute;
          top: 0; left: 0; right: 0;
          height: 1px;
          background: linear-gradient(90deg, transparent, rgba(168,85,247,.6), rgba(255,255,255,.3), rgba(168,85,247,.6), transparent);
          pointer-events: none;
          z-index: 2;
        }
        .aw-glass:hover {
          border-color: rgba(168,85,247,.4);
        }
        .aw-input {
          background: rgba(0,0,0,.5);
          border: 1px solid rgba(168,85,247,.25);
          color: #e9d5ff;
          transition: all .25s cubic-bezier(.16,1,.3,1);
        }
        .aw-input:focus {
          border-color: rgba(168,85,247,.6) !important;
          box-shadow: 0 0 0 3px rgba(168,85,247,.1), 0 0 20px -4px rgba(168,85,247,.4) !important;
          outline: none !important;
        }
        .aw-input::placeholder { color: rgba(161,161,170,.5); }
        .aw-btn-primary {
          background: linear-gradient(135deg, #a855f7, #7e22ce);
          color: #fff;
          border: none;
          box-shadow: 0 4px 16px -4px rgba(168,85,247,.6);
          transition: all .25s cubic-bezier(.16,1,.3,1);
        }
        .aw-btn-primary:hover:not(:disabled) {
          transform: translateY(-1px);
          box-shadow: 0 6px 20px -4px rgba(168,85,247,.8);
        }
        .aw-btn-primary:active:not(:disabled) { transform: translateY(0) scale(.98); }
        .aw-btn-ghost {
          background: rgba(0,0,0,.4);
          border: 1px solid rgba(168,85,247,.25);
          color: #c084fc;
          transition: all .25s cubic-bezier(.16,1,.3,1);
        }
        .aw-btn-ghost:hover:not(:disabled) {
          color: #e9d5ff;
          border-color: rgba(168,85,247,.5);
          transform: translateY(-1px);
        }
        .aw-tab-active {
          background: linear-gradient(135deg, rgba(168,85,247,.2), rgba(126,34,206,.08)) !important;
          border: 1px solid rgba(168,85,247,.4) !important;
          color: #e9d5ff !important;
        }
        .aw-tab-active .aw-tab-icon { color: #c084fc !important; }
        .aw-toggle:checked + .aw-toggle-track {
          background: linear-gradient(135deg, #a855f7, #7e22ce);
          box-shadow: 0 0 12px -2px rgba(168,85,247,.7);
        }
        .aw-feature-row {
          background: rgba(0,0,0,.35);
          border: 1px solid rgba(168,85,247,.15);
          transition: all .25s cubic-bezier(.16,1,.3,1);
        }
        .aw-feature-row:hover {
          border-color: rgba(168,85,247,.35);
        }
        .aw-scroll::-webkit-scrollbar { width: 8px; }
        .aw-scroll::-webkit-scrollbar-track { background: rgba(0,0,0,.3); }
        .aw-scroll::-webkit-scrollbar-thumb {
          background: linear-gradient(180deg, #a855f7, #7e22ce);
          border-radius: 4px;
        }
        .aw-settings-header {
          background: linear-gradient(135deg, rgba(20,12,35,.75), rgba(13,8,25,.9));
          backdrop-filter: blur(16px);
          border-bottom: 1px solid rgba(168,85,247,.25);
        }
        .aw-settings-sidebar {
          background: linear-gradient(180deg, rgba(15,8,28,.85) 0%, rgba(10,6,18,.95) 100%);
          backdrop-filter: blur(20px) saturate(1.4);
          border-right: 1px solid rgba(168,85,247,.25);
        }

        /* ═══ PREMIUM THEME SWATCHES ═══ */
        .aw-theme-swatch {
          position: relative;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 8px;
          padding: 12px 8px;
          border-radius: 16px;
          background: rgba(0,0,0,.4);
          border: 2px solid rgba(168,85,247,.15);
          cursor: pointer;
          transition: all .3s cubic-bezier(.16,1,.3,1);
        }
        .aw-theme-swatch:hover {
          transform: translateY(-2px) scale(1.02);
          border-color: rgba(168,85,247,.4);
        }
        .aw-theme-swatch.active {
          background: rgba(168,85,247,.15);
          border-color: rgba(168,85,247,.6);
          box-shadow: 0 0 24px -8px rgba(168,85,247,.5);
          transform: scale(1.05);
        }
        .aw-theme-circle {
          width: 44px;
          height: 44px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all .3s cubic-bezier(.16,1,.3,1);
        }
        .aw-theme-label {
          font-size: 10px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: .1em;
          color: #71717a;
          transition: color .2s ease;
        }
        .aw-theme-swatch.active .aw-theme-label { color: #e9d5ff; }
        .aw-theme-swatch:hover .aw-theme-label { color: #c084fc; }

        /* ═══ WALLPAPER PRESETS ═══ */
        .aw-wallpaper-preset {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 8px;
          border-radius: 12px;
          background: rgba(0,0,0,.4);
          border: 1px solid rgba(168,85,247,.2);
          cursor: pointer;
          transition: all .25s cubic-bezier(.16,1,.3,1);
          text-align: left;
        }
        .aw-wallpaper-preset:hover {
          border-color: rgba(168,85,247,.5);
          background: rgba(168,85,247,.1);
          transform: translateY(-1px);
        }

        /* ═══ SIDEBAR FOOTER ═══ */
        .aw-sidebar-footer {
          padding: 14px 16px;
          border-top: 1px solid rgba(168,85,247,.15);
          background: linear-gradient(180deg, rgba(0,0,0,0), rgba(168,85,247,.04));
          text-align: center;
          flex-shrink: 0;
        }
        .aw-sidebar-footer .aw-footer-title {
          font-size: 10px;
          font-weight: 700;
          letter-spacing: .12em;
          text-transform: uppercase;
          color: #a855f7;
          text-shadow: 0 0 12px rgba(168,85,247,.35);
        }
        .aw-sidebar-footer .aw-footer-sub {
          font-size: 9px;
          font-weight: 500;
          letter-spacing: .1em;
          text-transform: uppercase;
          color: #71717a;
          margin-top: 3px;
        }

        /* ═══ UPDATE CHECK ANIMATION ═══ */
        .aw-update-spinner {
          width: 16px;
          height: 16px;
          border-radius: 50%;
          border: 2px solid rgba(168,85,247,.3);
          border-top-color: #c084fc;
          animation: aw-spin .7s linear infinite;
        }
        @keyframes aw-spin {
          to { transform: rotate(360deg); }
        }
        .aw-update-glow {
          animation: aw-pulse-glow 2s ease-in-out infinite;
        }
        @keyframes aw-pulse-glow {
          0%, 100% { box-shadow: 0 0 20px -4px rgba(16,185,129,.5), inset 0 1px 0 rgba(255,255,255,.1); }
          50% { box-shadow: 0 0 32px -2px rgba(16,185,129,.8), inset 0 1px 0 rgba(255,255,255,.2); }
        }
        .aw-update-success {
          animation: aw-fade-slide .5s cubic-bezier(.16,1,.3,1);
        }
        @keyframes aw-fade-slide {
          from { opacity: 0; transform: translateY(-8px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .aw-check-pop {
          animation: aw-pop .5s cubic-bezier(.16,1,.3,1);
        }
        @keyframes aw-pop {
          0% { transform: scale(.4); opacity: 0; }
          60% { transform: scale(1.15); opacity: 1; }
          100% { transform: scale(1); opacity: 1; }
        }
      `}} />

      <div className="flex h-[100dvh] w-full bg-transparent text-purple-100 font-sans overflow-hidden selection:bg-purple-500/30">
        {mobileOpen && (
          <div
            className="fixed inset-0 bg-black/70 backdrop-blur-md z-[60] md:hidden"
            onClick={() => setMobileOpen(false)}
          />
        )}

        <div className={`fixed inset-y-0 left-0 z-[70] transform flex-shrink-0 aw-settings-sidebar transition-transform duration-300 ${mobileOpen ? 'translate-x-0' : '-translate-x-full'} md:relative md:translate-x-0 w-64 h-full flex flex-col`}>
          <div className="h-16 flex items-center justify-between border-b border-purple-500/20 px-6 flex-shrink-0">
            <span className="font-display font-bold text-lg tracking-wide uppercase flex items-center gap-1.5">
              <span className="text-purple-400">ADMIN</span>
              <span className="text-zinc-500 font-medium">PANEL</span>
              <Hexagon size={12} className="text-purple-500" />
            </span>
            <button onClick={() => setMobileOpen(false)} className="md:hidden text-zinc-400 hover:text-white transition-colors">
              <X size={20} />
            </button>
          </div>

          <nav className="flex-1 w-full px-3 py-6 space-y-1.5 overflow-y-auto aw-scroll">
            <p className="px-3 mb-4 font-mono text-[10px] text-purple-400/60 tracking-widest uppercase">Settings</p>

            {adminTabs.map(tab => {
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => scrollToTab(tab.id)}
                  className={`relative flex w-full items-center px-3 py-3 rounded-xl transition-all group overflow-hidden ${
                    isActive ? 'aw-tab-active' : 'hover:bg-purple-500/8 border border-transparent'
                  }`}
                >
                  <div className={`relative z-10 transition-colors duration-200 aw-tab-icon ${isActive ? 'text-purple-400' : 'text-zinc-500 group-hover:text-purple-300'}`}>
                    {tab.icon}
                  </div>
                  <span className={`ml-3 relative z-10 font-mono text-xs tracking-wider transition-colors duration-200 ${isActive ? 'text-purple-200 font-semibold' : 'text-zinc-500 group-hover:text-purple-200'}`}>
                    {tab.label.toUpperCase()}
                  </span>
                </button>
              );
            })}

            <div className="mt-8 pt-4">
              <Link to="/" className="relative flex items-center px-3 py-3 rounded-xl transition-colors group hover:bg-purple-500/8">
                <div className="relative z-10 text-zinc-500 group-hover:text-purple-300 transition-colors">
                  <ArrowLeft size={20} />
                </div>
                <span className="ml-3 font-mono text-xs tracking-wider transition-colors text-zinc-500 group-hover:text-purple-200">BACK TO APP</span>
              </Link>
            </div>
          </nav>

          {/* ═══ SIDEBAR FOOTER ═══ */}
          <div className="aw-sidebar-footer">
            <div className="aw-footer-title">AstroWax Panel V1.80</div>
            <div className="aw-footer-sub">Powered By JTG Panel</div>
          </div>
        </div>

        <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden relative bg-transparent">
          <header className="sticky top-0 z-40 aw-settings-header flex-shrink-0 h-16 flex items-center px-4 md:px-8">
            <button
              onClick={() => setMobileOpen(true)}
              className="md:hidden p-2 -ml-2 mr-3 text-zinc-400 hover:text-purple-300 hover:bg-purple-500/10 rounded-lg transition-colors flex items-center justify-center"
            >
              <Menu className="w-5 h-5" />
            </button>
            <h1 className="font-display font-bold text-xl uppercase tracking-wide flex items-center gap-2 text-purple-200">
              {adminTabs.find(t => t.id === activeTab)?.label}
              <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[9px] font-mono uppercase tracking-widest bg-purple-500/10 border border-purple-500/30 text-purple-400">
                <Hexagon size={9} />
                ASTROWAX
              </span>
            </h1>
          </header>

          <main id="settings-scroll-container" className="flex-1 w-full h-full relative z-0 overflow-x-hidden overflow-y-auto pb-safe aw-scroll p-4 sm:p-6 md:p-8">
            <div className="max-w-4xl mx-auto w-full pb-12">
              <div className="flex flex-col gap-8 pt-4">

                {/* ═══════════════════════════════════════
                    BRANDING SECTION
                ═══════════════════════════════════════ */}
                <section id="branding" className="scroll-mt-24 aw-glass p-6 md:p-8">
                  <h2 className="text-xl font-bold mb-6 flex items-center text-purple-200 relative z-10">
                    <Layout className="mr-3 text-purple-400 w-5 h-5" /> Branding
                  </h2>
                  <div className="flex flex-col gap-8 relative z-10">
                    <form
                      onSubmit={async (e: any) => {
                        e.preventDefault();
                        setIsSavingSettings(true);
                        try {
                          await axios.put("/api/system/settings", { panelName: newPanelName });
                          fetchSettings();
                        } catch (err: any) {
                          alert(err.response?.data?.error || "Error updating settings");
                        } finally {
                          setIsSavingSettings(false);
                        }
                      }}
                    >
                      <label className="block text-xs font-semibold text-purple-300 mb-2 uppercase tracking-wider">Panel Name</label>
                      <div className="flex gap-3">
                        <input
                          required
                          value={newPanelName}
                          onChange={(e: any) => setNewPanelName(e.target.value)}
                          type="text"
                          placeholder="Enter panel name"
                          className="aw-input flex-1 rounded-xl px-4 py-2.5"
                        />
                        <button disabled={isSavingSettings} type="submit" className="aw-btn-primary px-6 py-2.5 rounded-xl font-semibold whitespace-nowrap disabled:opacity-50">
                          {isSavingSettings ? "Saving..." : "Save"}
                        </button>
                      </div>
                    </form>

                    <div>
                      <label className="block text-xs font-semibold text-purple-300 mb-3 uppercase tracking-wider">Panel Logo</label>
                      <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4">
                        <div className="w-20 h-20 rounded-2xl bg-black/40 border border-purple-500/25 flex items-center justify-center overflow-hidden flex-shrink-0 relative group">
                          {panelLogo ? (
                            <img src={panelLogo} alt="Panel Logo" className="w-full h-full object-cover" />
                          ) : (
                            <Layout className="w-8 h-8 text-purple-400/40" />
                          )}
                          {panelLogo && (
                            <button
                              onClick={async () => {
                                try {
                                  await axios.put("/api/system/settings", { panelLogo: "" });
                                  fetchSettings();
                                } catch (e) { }
                              }}
                              className="absolute inset-0 bg-rose-500/80 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-sm"
                              title="Remove logo"
                            >
                              <Trash2 size={20} className="text-white" />
                            </button>
                          )}
                        </div>

                        <div className="flex-1 w-full text-center sm:text-left">
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            ref={fileInputRef}
                            onChange={(e: any) => handleFileChange(e, "logo")}
                          />
                          <button
                            disabled={isUpdatingLogo}
                            onClick={() => fileInputRef.current?.click()}
                            className="aw-btn-ghost inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl font-medium disabled:opacity-50 w-full sm:w-auto mb-2"
                          >
                            {isUpdatingLogo ? <div className="w-4 h-4 rounded-full border-2 border-purple-400/30 border-t-purple-400 animate-spin"></div> : <Upload size={18} />}
                            {isUpdatingLogo ? "Uploading..." : (panelLogo ? "Replace Logo" : "Upload Logo")}
                          </button>
                          <p className="text-xs text-zinc-500">We recommend a square image, PNG or JPG format, at least 256x256px.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </section>

                {/* ═══════════════════════════════════════
                    FEATURES SECTION
                ═══════════════════════════════════════ */}
                <section id="features" className="scroll-mt-24 aw-glass p-6 md:p-8">
                  <h2 className="text-xl font-bold mb-6 flex items-center text-purple-200 relative z-10">
                    <Settings className="mr-3 text-purple-400 w-5 h-5" /> Features
                  </h2>
                  <div className="flex flex-col gap-4 relative z-10">

                    {[
                      { key: 'playit', title: 'Playit Tunnel Integration', desc: 'Allow users to expose their local servers to the internet using playit.gg tunnels.', value: newEnablePlayit, setter: setNewEnablePlayit, apiKey: 'enablePlayit' },
                      { key: 'tutorial', title: 'Onboarding Tutorial', desc: 'Show a guided tour to new users when they log in for the first time.', value: newEnableTutorial, setter: setNewEnableTutorial, apiKey: 'enableTutorial' },
                      { key: 'loginanim', title: 'Cinematic Login Intro', desc: 'Enable the animated sequence on the login screen.', value: newEnableLoginAnimation, setter: setNewEnableLoginAnimation, apiKey: 'enableLoginAnimation' },
                      { key: 'reg', title: 'User Registration', desc: 'Allow new users to register an account on the panel.', value: newEnableRegistration, setter: setNewEnableRegistration, apiKey: 'enableRegistration' },
                    ].map(item => (
                      <div key={item.key} className="aw-feature-row flex items-start justify-between gap-4 p-4 rounded-2xl">
                        <div>
                          <h3 className="font-semibold text-purple-200 text-sm">{item.title}</h3>
                          <p className="text-xs text-zinc-500 mt-1">{item.desc}</p>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer flex-shrink-0 mt-1">
                          <input
                            type="checkbox"
                            checked={item.value}
                            onChange={async (e: any) => {
                              const val = e.target.checked;
                              item.setter(val);
                              try {
                                await axios.put("/api/system/settings", { [item.apiKey]: val });
                                fetchSettings();
                              } catch (err) { console.error(err); }
                            }}
                            className="sr-only peer aw-toggle"
                          />
                          <div className="aw-toggle-track w-11 h-6 bg-zinc-800 border border-purple-500/20 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-zinc-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all"></div>
                        </label>
                      </div>
                    ))}
                  </div>
                </section>

                {/* ═══════════════════════════════════════
                    RUNTIME SECTION
                ═══════════════════════════════════════ */}
                <section id="runtime" className="scroll-mt-24 aw-glass p-6 md:p-8">
                  <div className="flex items-center justify-between mb-6 relative z-10 flex-wrap gap-3">
                    <h2 className="text-xl font-bold flex items-center text-purple-200">
                      <Cpu className="mr-3 text-purple-400 w-5 h-5" /> Runtime Engine
                    </h2>
                    {!isDevPanel ? (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-[10px] font-mono font-medium uppercase bg-amber-500/10 text-amber-400 border border-amber-500/25">
                        <Lock className="w-3 h-3" /> Main Panel (Locked)
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-[10px] font-mono font-medium uppercase bg-emerald-500/10 text-emerald-400 border border-emerald-500/25">
                        Developer Mode (Unlocked)
                      </span>
                    )}
                  </div>
                  <div className="relative z-10 space-y-6">
                    <div>
                      <h4 className="font-semibold text-purple-200 flex items-center gap-2">Default Server Runtime</h4>
                      <p className="text-xs text-zinc-500 mt-1 mb-4">
                        Execution environment for <strong className="text-purple-300">newly created servers</strong>.
                      </p>

                      {!isDevPanel && (
                        <div className="mb-5 p-4 rounded-xl bg-black/60 border border-amber-500/25 text-xs text-zinc-300 flex items-start gap-3">
                          <Lock className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                          <div>
                            <p className="font-semibold text-white">Default Runtime Locked on Main Panel</p>
                            <p className="mt-1 text-zinc-400 leading-relaxed">
                              The runtime engine is locked to the host installation default (<strong className="text-amber-300 uppercase">{newDefaultRuntime === 'local' ? 'Local Process' : 'Docker Container'}</strong>). Changing default runtime can only be done during panel installation/reinstallation (<code className="text-zinc-300">bash install.sh</code>) or via the Developer Panel (Port 3000).
                            </p>
                          </div>
                        </div>
                      )}

                      {runtimeStatusMsg && (
                        <div className={`mb-4 p-3 rounded-xl text-sm font-medium border flex items-center gap-2 ${runtimeStatusMsg.type === "success"
                            ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400"
                            : runtimeStatusMsg.type === "warning"
                              ? "bg-amber-500/10 border-amber-500/30 text-amber-400"
                              : "bg-rose-500/10 border-rose-500/30 text-rose-400"
                          }`}>
                          <AlertCircle className="w-4 h-4 shrink-0" />
                          <span>{runtimeStatusMsg.text}</span>
                        </div>
                      )}

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {[
                          { value: 'docker', label: 'Docker (Container Isolation)', desc: 'Runs server workloads in sandboxed Docker containers. Full port isolation, PTY terminal support, high security.', engine: 'Docker Engine', badge: 'Isolated', color: 'purple' },
                          { value: 'local', label: 'Local Process (Direct Process)', desc: 'Runs server workloads directly on the host system via Node.js process spawning. Ideal for environments without Docker.', engine: 'Host Java / Node Execution', badge: 'Direct Host', color: 'amber' },
                        ].map(opt => {
                          const isActive = newDefaultRuntime === opt.value;
                          const isDisabled = !isDevPanel;
                          const colorClass = opt.color === 'purple' ? 'purple' : 'amber';
                          return (
                            <button
                              key={opt.value}
                              type="button"
                              disabled={isDisabled || isUpdatingRuntime}
                              onClick={async () => {
                                if (!isDevPanel) return;
                                setIsUpdatingRuntime(true);
                                setRuntimeStatusMsg(null);
                                setNewDefaultRuntime(opt.value);
                                if (setDefaultRuntime) setDefaultRuntime(opt.value);
                                try {
                                  const token = localStorage.getItem("astrowax_token") || localStorage.getItem("jtg_token") || localStorage.getItem("token");
                                  const headers: any = {};
                                  if (token) headers["Authorization"] = `Bearer ${token}`;
                                  await axios.put("/api/system/settings", { defaultRuntime: opt.value }, { headers });
                                  await fetchSettings();
                                  setRuntimeStatusMsg({ text: `Default runtime updated to ${opt.label}.`, type: "success" });
                                } catch (err: any) {
                                  setRuntimeStatusMsg({ text: err.response?.data?.error || err.message || "Failed to update runtime", type: "error" });
                                } finally {
                                  setIsUpdatingRuntime(false);
                                }
                              }}
                              className={`p-5 rounded-2xl border text-left transition-all relative overflow-hidden flex flex-col justify-between ${
                                isActive
                                  ? colorClass === 'purple'
                                    ? 'bg-purple-500/15 border-purple-500 shadow-lg shadow-purple-500/10 ring-1 ring-purple-500'
                                    : 'bg-amber-500/15 border-amber-500 shadow-lg shadow-amber-500/10 ring-1 ring-amber-500'
                                  : isDisabled
                                    ? 'bg-black/30 border-purple-500/10 opacity-40 cursor-not-allowed filter grayscale pointer-events-none'
                                    : 'bg-black/40 border-purple-500/20 hover:border-purple-500/40 hover:bg-black/50'
                              } ${isDisabled ? 'cursor-not-allowed' : 'cursor-pointer'}`}
                            >
                              <div>
                                <div className="flex items-center justify-between mb-2 flex-wrap gap-2">
                                  <span className={`text-sm font-bold flex items-center gap-2 ${isActive ? colorClass === 'purple' ? 'text-purple-300' : 'text-amber-300' : 'text-purple-100'}`}>
                                    {opt.label}
                                  </span>
                                  {isActive && (
                                    <span className={`text-[10px] font-mono uppercase px-2 py-0.5 rounded-full font-semibold flex items-center gap-1 ${
                                      isDisabled
                                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                                        : colorClass === 'purple'
                                          ? 'bg-gradient-to-r from-purple-500 to-purple-700 text-white'
                                          : 'bg-amber-500 text-black'
                                    }`}>
                                      {isDisabled && <Lock className="w-2.5 h-2.5" />}
                                      {isDisabled ? 'Installed Default' : 'Active'}
                                    </span>
                                  )}
                                </div>
                                <p className="text-xs text-zinc-500 leading-relaxed">{opt.desc}</p>
                              </div>
                              <div className="mt-4 pt-3 border-t border-purple-500/15 flex items-center justify-between text-[11px] text-zinc-500">
                                <span>{opt.engine}</span>
                                <span className={`font-mono font-semibold ${colorClass === 'purple' ? 'text-purple-400' : 'text-amber-400'}`}>{opt.badge}</span>
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    <div className="p-4 rounded-xl bg-black/40 border border-purple-500/20 text-xs text-zinc-400 space-y-1">
                      <p className="font-semibold text-purple-200">💡 How Runtime Configuration Works:</p>
                      <p>• On the <strong>Main Panel</strong>, runtime is locked to what was configured during panel installation/reinstallation (<code className="text-purple-300">bash install.sh</code>).</p>
                      <p>• Dynamic runtime switching and per-server conversion are strictly reserved for the <strong>Developer Panel (Port 3000)</strong>.</p>
                    </div>
                  </div>
                </section>

                {/* ═══════════════════════════════════════
                    APPEARANCE SECTION
                ═══════════════════════════════════════ */}
                <section id="appearance" className="scroll-mt-24 aw-glass p-6 md:p-8">
                  <h2 className="text-xl font-bold mb-6 flex items-center text-purple-200 relative z-10">
                    <ImageIcon className="mr-3 text-purple-400 w-5 h-5" /> Appearance
                  </h2>
                  <div className="relative z-10">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="space-y-6">
                        <div>
                          <label className="block text-xs font-semibold text-purple-300 mb-3 uppercase tracking-wider">Custom Dashboard Background</label>
                          <div className="flex gap-4 items-end">
                            <div className="w-32 h-20 rounded-xl border-2 border-dashed border-purple-500/30 bg-black/40 overflow-hidden relative group flex-shrink-0 flex items-center justify-center">
                              {panelBackgroundImage ? (
                                <img src={panelBackgroundImage} alt="Background Preview" className="w-full h-full object-cover" style={{ filter: `blur(${panelBackgroundBlur}px)` }} />
                              ) : (
                                <ImageIcon className="w-6 h-6 text-purple-400/40" />
                              )}
                            </div>
                            <div className="flex-1 space-y-2">
                              <input
                                type="file"
                                accept="image/*"
                                className="hidden"
                                ref={bgFileInputRef}
                                onChange={(e: any) => handleFileChange(e, "background")}
                              />
                              <button
                                disabled={isProcessing}
                                onClick={() => bgFileInputRef.current?.click()}
                                className="aw-btn-primary w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-medium disabled:opacity-50 text-sm"
                              >
                                {isProcessing ? <div className="w-4 h-4 rounded-full border-2 border-white/30 border-t-white animate-spin"></div> : <Upload size={16} />}
                                {isProcessing ? "Uploading..." : "Upload Image"}
                              </button>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 pt-2 border-t border-purple-500/15">
                          <button
                            disabled={isProcessing}
                            onClick={async () => {
                              setIsProcessing(true);
                              try {
                                await axios.put("/api/system/settings", { panelBackgroundImage: "", panelBackgroundBlur: 0 });
                                setCustomBgUrlInput("");
                                await fetchSettings();
                              } catch (e) { } finally {
                                setIsProcessing(false);
                              }
                            }}
                            className="aw-btn-ghost flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-medium text-sm"
                          >
                            Reset
                          </button>
                        </div>

                        <div className="space-y-2 pt-2">
                          <label className="block text-xs font-medium text-purple-300">Or Enter Custom Image URL</label>
                          <div className="flex gap-2">
                            <input
                              type="url"
                              placeholder="https://example.com/wallpaper.jpg"
                              value={customBgUrlInput}
                              onChange={(e) => setCustomBgUrlInput(e.target.value)}
                              className="aw-input flex-1 rounded-xl px-3 py-2 text-sm"
                            />
                            <button
                              onClick={async () => {
                                if (!customBgUrlInput.trim()) return;
                                setIsProcessing(true);
                                try {
                                  await axios.put("/api/system/settings", { panelBackgroundImage: customBgUrlInput.trim() });
                                  await fetchSettings();
                                } catch (e) { } finally {
                                  setIsProcessing(false);
                                }
                              }}
                              className="aw-btn-ghost px-4 py-2 rounded-xl text-sm"
                            >
                              Apply URL
                            </button>
                          </div>
                        </div>

                        {/* ═══ PREMIUM COLOR THEMES ═══ */}
                        <div className="space-y-4 pt-6 border-t border-purple-500/15">
                          <div>
                            <label className="block text-xs font-bold text-purple-300 uppercase tracking-widest flex items-center gap-2">
                              <Palette size={14} />
                              Premium Accent Theme
                            </label>
                            <p className="text-xs text-zinc-500 mt-1 mb-4">
                              Choose from 5 hand-crafted gradient themes. Applies instantly.
                            </p>
                          </div>
                          <div className="grid grid-cols-5 gap-2">
                            {PREMIUM_THEMES.map((t) => {
                              const isActive = (newTheme || theme) === t.id;
                              return (
                                <button
                                  key={t.id}
                                  onClick={() => applyTheme(t.id)}
                                  className={`aw-theme-swatch ${isActive ? 'active' : ''}`}
                                  title={t.name}
                                >
                                  <div
                                    className="aw-theme-circle"
                                    style={{
                                      background: t.gradient,
                                      boxShadow: isActive
                                        ? `0 0 24px -4px ${t.glow}, inset 0 1px 0 rgba(255,255,255,.3)`
                                        : `0 4px 12px -4px ${t.glow}, inset 0 1px 0 rgba(255,255,255,.2)`
                                    }}
                                  >
                                    {isActive && <Check size={18} className="text-white" strokeWidth={3} />}
                                  </div>
                                  <span className="aw-theme-label">{t.name}</span>
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      </div>

                      <div className="space-y-6 flex flex-col justify-between">
                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <label className="text-xs font-bold text-purple-300 uppercase tracking-widest">Background Blur ({tempBgBlur}px)</label>
                            <span className="text-xs text-zinc-500">{tempBgBlur === 0 ? "Sharp" : tempBgBlur > 20 ? "Heavy Blur" : "Soft Blur"}</span>
                          </div>
                          <p className="text-xs text-zinc-500 mb-4">Adjust background blur for crisp dashboard readability.</p>
                          <input
                            type="range"
                            min="0"
                            max="50"
                            value={tempBgBlur}
                            onChange={(e: any) => setTempBgBlur(Number(e.target.value))}
                            onMouseUp={async () => {
                              setIsProcessing(true);
                              try {
                                await axios.put("/api/system/settings", { panelBackgroundBlur: tempBgBlur });
                                await fetchSettings();
                              } catch (e) { } finally {
                                setIsProcessing(false);
                              }
                            }}
                            onTouchEnd={async () => {
                              setIsProcessing(true);
                              try {
                                await axios.put("/api/system/settings", { panelBackgroundBlur: tempBgBlur });
                                await fetchSettings();
                              } catch (e) { } finally {
                                setIsProcessing(false);
                              }
                            }}
                            className="w-full accent-purple-500"
                          />
                        </div>

                        {/* ═══ WALLPAPER PRESETS ═══ */}
                        <div className="space-y-3 pt-4 border-t border-purple-500/15">
                          <label className="block text-xs font-bold text-purple-300 uppercase tracking-widest">Quick Wallpaper Presets</label>
                          <div className="grid grid-cols-2 gap-2">
                            {WALLPAPER_PRESETS.map((preset) => (
                              <button
                                key={preset.name}
                                onClick={async () => {
                                  setIsProcessing(true);
                                  setCustomBgUrlInput(preset.url);
                                  try {
                                    await axios.put("/api/system/settings", { panelBackgroundImage: preset.url });
                                    await fetchSettings();
                                  } catch (e) { } finally {
                                    setIsProcessing(false);
                                  }
                                }}
                                className="aw-wallpaper-preset group"
                              >
                                <img
                                  src={preset.url}
                                  alt={preset.name}
                                  className="w-10 h-10 rounded-lg object-cover group-hover:scale-105 transition-transform border border-purple-500/20"
                                />
                                <span className="text-xs font-medium text-purple-200 group-hover:text-purple-100 truncate">{preset.name}</span>
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </section>

                {/* ═══════════════════════════════════════
                    AUTH SECTION
                ═══════════════════════════════════════ */}
                <div id="auth" className="scroll-mt-24">
                  {renderGoogleFirebase()}
                </div>

                {/* ═══════════════════════════════════════
                    USERS SECTION
                ═══════════════════════════════════════ */}
                <div id="users" className="scroll-mt-24">
                  <AdminControls
                    user={user}
                    users={users}
                    username={username}
                    setUsername={setUsername}
                    password={password}
                    setPassword={setPassword}
                    role={role}
                    setRole={setRole}
                    isCreatingUser={isCreatingUser}
                    createUser={createUser}
                    editingUserId={editingUserId}
                    setEditingUserId={setEditingUserId}
                    adminUserNewPassword={adminUserNewPassword}
                    setAdminUserNewPassword={setAdminUserNewPassword}
                    changeUserPassword={changeUserPassword}
                    deleteUser={deleteUser}
                    changeUserRole={changeUserRole}
                  />
                </div>

                {/* ═══════════════════════════════════════
                    SYSTEM SECTION — Check for Updates
                ═══════════════════════════════════════ */}
                <section id="system" className="scroll-mt-24 aw-glass p-6 md:p-8">
                  <div className="flex items-center justify-between mb-4 relative z-10 flex-wrap gap-3">
                    <h2 className="text-xl font-bold flex items-center text-purple-200">
                      <RefreshCw className="mr-3 text-purple-400 w-5 h-5" /> System Update
                    </h2>
                    <span
                      className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-[10px] font-mono font-medium uppercase"
                      style={{
                        background: 'rgba(16,185,129,.12)',
                        color: '#34d399',
                        border: '1px solid rgba(16,185,129,.35)',
                      }}
                    >
                      <CheckCircle2 className="w-3 h-3" /> Latest
                    </span>
                  </div>
                  <div className="relative z-10">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
                      <div className="p-3 rounded-xl bg-black/40 border border-purple-500/20">
                        <div className="text-[10px] uppercase font-mono tracking-wider text-zinc-500">Version</div>
                        <div className="text-sm font-bold font-mono text-purple-400 mt-0.5">v{PANEL_VERSION}</div>
                      </div>
                      <div className="p-3 rounded-xl bg-black/40 border border-emerald-500/25">
                        <div className="text-[10px] uppercase font-mono tracking-wider text-zinc-500">Status</div>
                        <div className="text-sm font-bold font-mono text-emerald-400 mt-0.5">Up to date</div>
                      </div>
                      <div className="p-3 rounded-xl bg-black/40 border border-purple-500/20">
                        <div className="text-[10px] uppercase font-mono tracking-wider text-zinc-500">Main Port</div>
                        <div className="text-sm font-bold font-mono text-purple-400 mt-0.5">6767</div>
                      </div>
                      <div className="p-3 rounded-xl bg-black/40 border border-purple-500/20">
                        <div className="text-[10px] uppercase font-mono tracking-wider text-zinc-500">Default Driver</div>
                        <div className="text-sm font-bold font-mono text-purple-400 mt-0.5 capitalize">{defaultRuntime || "Docker"}</div>
                      </div>
                    </div>

                    <p className="text-zinc-400 text-sm mb-6 max-w-2xl">
                      Click the button below to check for the latest version of AstroWax Panel. The panel will compare your installation with the official release channel.
                    </p>

                    <div className="flex flex-wrap items-center gap-3">
                      <button
                        onClick={handleSystemUpdate}
                        disabled={updateCheckStatus === "checking"}
                        className={`px-6 py-2.5 rounded-xl font-bold flex items-center transition-all ${
                          updateCheckStatus === "checking"
                            ? "cursor-wait opacity-80"
                            : "aw-btn-primary hover:translate-y-[-1px]"
                        }`}
                      >
                        {updateCheckStatus === "checking" ? (
                          <>
                            <div className="aw-update-spinner mr-2"></div>
                            Checking for updates...
                          </>
                        ) : updateCheckStatus === "up-to-date" ? (
                          <>
                            <CheckCircle2 className="w-4 h-4 mr-2" />
                            Check Again
                          </>
                        ) : (
                          <>
                            <RefreshCw className="w-4 h-4 mr-2" />
                            Check for Updates
                          </>
                        )}
                      </button>
                    </div>

                    {/* ═══ UP TO DATE MESSAGE ═══ */}
                    {updateCheckStatus === "up-to-date" && (
                      <div
                        className="aw-update-success aw-update-glow mt-6 p-5 rounded-2xl flex items-start gap-4"
                        style={{
                          background: 'linear-gradient(135deg, rgba(16,185,129,.1), rgba(16,185,129,.02))',
                          border: '1px solid rgba(16,185,129,.35)',
                        }}
                      >
                        <div
                          className="aw-check-pop flex items-center justify-center w-10 h-10 rounded-full flex-shrink-0"
                          style={{
                            background: 'linear-gradient(135deg, #10b981, #047857)',
                            boxShadow: '0 0 20px -2px rgba(16,185,129,.7)',
                          }}
                        >
                          <Check className="w-5 h-5 text-white" strokeWidth={3} />
                        </div>
                        <div className="flex-1">
                          <p className="text-emerald-300 font-bold text-sm mb-1">
                            You are running the latest version of AstroWax Panel!
                          </p>
                          <p className="text-emerald-200/80 text-xs leading-relaxed">
                            Your panel is fully up to date on <strong className="text-emerald-300">v{PANEL_VERSION}</strong>. No action is required. We'll notify you here when a new release becomes available.
                          </p>
                          <div className="flex flex-wrap items-center gap-3 mt-3 text-[10px] font-mono uppercase tracking-widest text-emerald-400/80">
                            <span className="inline-flex items-center gap-1">
                              <CheckCircle2 size={11} /> Version {PANEL_VERSION}
                            </span>
                            <span className="inline-flex items-center gap-1">
                              <CheckCircle2 size={11} /> All files verified
                            </span>
                            <span className="inline-flex items-center gap-1">
                              <CheckCircle2 size={11} /> No updates available
                            </span>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* ═══ CHECKING IN-PROGRESS INFO ═══ */}
                    {updateCheckStatus === "checking" && (
                      <div
                        className="aw-update-success mt-6 p-4 rounded-2xl flex items-center gap-3 text-xs"
                        style={{
                          background: 'rgba(168,85,247,.08)',
                          border: '1px solid rgba(168,85,247,.3)',
                          color: '#c084fc',
                        }}
                      >
                        <div className="aw-update-spinner flex-shrink-0"></div>
                        <span>Contacting AstroWax release server... comparing file signatures and version metadata.</span>
                      </div>
                    )}
                  </div>
                </section>

                {/* ═══════════════════════════════════════
                    ANNOUNCEMENTS SECTION — admin-only
                ═══════════════════════════════════════ */}
                <section id="announcements" className="scroll-mt-24 aw-glass p-6 md:p-8">
                  <h2 className="text-xl font-bold mb-2 flex items-center text-purple-200 relative z-10">
                    <Megaphone className="mr-3 text-purple-400 w-5 h-5" /> Announcements
                  </h2>
                  <p className="text-xs text-zinc-500 mb-6 relative z-10">
                    Only admins/owners can post these. Active announcements appear as a banner for every user on the panel.
                  </p>

                  <form onSubmit={handleSaveAnnouncement} className="relative z-10 flex flex-col gap-3 mb-8 p-4 rounded-2xl aw-feature-row">
                    <div className="grid grid-cols-1 sm:grid-cols-[1fr_140px] gap-3">
                      <input
                        type="text"
                        placeholder="Title"
                        value={announcementForm.title}
                        onChange={e => setAnnouncementForm(f => ({ ...f, title: e.target.value }))}
                        className="aw-input w-full rounded-xl px-4 py-2.5 text-sm"
                        maxLength={200}
                      />
                      <select
                        value={announcementForm.severity}
                        onChange={e => setAnnouncementForm(f => ({ ...f, severity: e.target.value }))}
                        className="aw-input w-full rounded-xl px-4 py-2.5 text-sm"
                      >
                        <option value="info">Info</option>
                        <option value="success">Success</option>
                        <option value="warning">Warning</option>
                        <option value="critical">Critical</option>
                      </select>
                    </div>
                    <textarea
                      placeholder="Message"
                      value={announcementForm.message}
                      onChange={e => setAnnouncementForm(f => ({ ...f, message: e.target.value }))}
                      className="aw-input w-full rounded-xl px-4 py-2.5 text-sm min-h-[80px] resize-y"
                      maxLength={2000}
                    />
                    <div className="flex flex-wrap items-center gap-3">
                      <label className="text-xs text-zinc-500 flex items-center gap-2">
                        Expires
                        <input
                          type="date"
                          value={announcementForm.expiresAt}
                          onChange={e => setAnnouncementForm(f => ({ ...f, expiresAt: e.target.value }))}
                          className="aw-input rounded-xl px-3 !py-1.5 text-sm"
                        />
                      </label>
                      <div className="flex-1" />
                      {editingAnnouncementId && (
                        <button type="button" onClick={resetAnnouncementForm} className="aw-btn-ghost px-4 py-2 rounded-xl text-sm">
                          Cancel Edit
                        </button>
                      )}
                      <button disabled={isSavingAnnouncement} type="submit" className="aw-btn-primary px-5 py-2 rounded-xl font-semibold text-sm disabled:opacity-50">
                        {editingAnnouncementId ? "Update Announcement" : "Post Announcement"}
                      </button>
                    </div>
                    {announcementMsg && (
                      <p className={`text-xs ${announcementMsg.type === "success" ? "text-emerald-400" : "text-red-400"}`}>
                        {announcementMsg.text}
                      </p>
                    )}
                  </form>

                  <div className="relative z-10 flex flex-col gap-3">
                    {isLoadingAnnouncements && <p className="text-xs text-zinc-500">Loading...</p>}
                    {!isLoadingAnnouncements && announcements.length === 0 && (
                      <p className="text-xs text-zinc-500">No announcements yet.</p>
                    )}
                    {announcements.map(a => (
                      <div key={a.id} className="aw-feature-row flex items-start justify-between gap-4 p-4 rounded-2xl">
                        <div className="min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span
                              className="text-[10px] font-mono uppercase px-2 py-0.5 rounded"
                              style={{
                                background:
                                  a.severity === "critical" ? "rgba(239,68,68,.15)" :
                                  a.severity === "warning" ? "rgba(245,158,11,.15)" :
                                  a.severity === "success" ? "rgba(16,185,129,.15)" : "rgba(168,85,247,.15)",
                                color:
                                  a.severity === "critical" ? "#f87171" :
                                  a.severity === "warning" ? "#fbbf24" :
                                  a.severity === "success" ? "#34d399" : "#c084fc",
                              }}
                            >
                              {a.severity}
                            </span>
                            <h3 className="font-semibold text-purple-200 text-sm truncate">{a.title}</h3>
                            {!a.active && <span className="text-[10px] font-mono uppercase text-zinc-600">hidden</span>}
                          </div>
                          <p className="text-xs text-zinc-500 mt-1 whitespace-pre-wrap">{a.message}</p>
                          {a.expiresAt && (
                            <p className="text-[10px] text-zinc-600 mt-1">Expires {new Date(a.expiresAt).toLocaleDateString()}</p>
                          )}
                        </div>
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <label className="relative inline-flex items-center cursor-pointer">
                            <input
                              type="checkbox"
                              checked={!!a.active}
                              onChange={() => toggleAnnouncementActive(a)}
                              className="sr-only peer aw-toggle"
                            />
                            <div className="aw-toggle-track w-9 h-5 bg-zinc-800 border border-purple-500/20 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-zinc-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all"></div>
                          </label>
                          <button onClick={() => startEditAnnouncement(a)} className="aw-btn-ghost p-2 rounded-lg" title="Edit">
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          <button onClick={() => deleteAnnouncement(a.id)} className="aw-btn-ghost p-2 rounded-lg text-red-400" title="Delete">
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </section>

                {/* ═══════════════════════════════════════
                    SERVER LIMITS SECTION — admin-only
                ═══════════════════════════════════════ */}
                <section id="limits" className="scroll-mt-24 aw-glass p-6 md:p-8">
                  <h2 className="text-xl font-bold mb-2 flex items-center text-purple-200 relative z-10">
                    <SlidersHorizontal className="mr-3 text-purple-400 w-5 h-5" /> Server Limits
                  </h2>
                  <p className="text-xs text-zinc-500 mb-6 relative z-10">
                    Controls the fixed plan and cap every regular (non-admin) user gets. Admins/owners are never limited by this.
                  </p>

                  <form onSubmit={handleSaveLimits} className="relative z-10 grid grid-cols-2 sm:grid-cols-3 gap-4">
                    <label className="flex flex-col gap-1.5 text-xs text-zinc-500">
                      RAM per server (GB)
                      <input
                        type="number" min={1} max={1024}
                        value={limitsForm.ram}
                        onChange={e => setLimitsForm(f => ({ ...f, ram: Number(e.target.value) }))}
                        className="aw-input w-full rounded-xl px-4 py-2.5 text-sm"
                      />
                    </label>
                    <label className="flex flex-col gap-1.5 text-xs text-zinc-500">
                      CPU per server (%)
                      <input
                        type="number" min={10} max={3200}
                        value={limitsForm.cpu}
                        onChange={e => setLimitsForm(f => ({ ...f, cpu: Number(e.target.value) }))}
                        className="aw-input w-full rounded-xl px-4 py-2.5 text-sm"
                      />
                    </label>
                    <label className="flex flex-col gap-1.5 text-xs text-zinc-500">
                      Disk per server (GB)
                      <input
                        type="number" min={1} max={4096}
                        value={limitsForm.disk}
                        onChange={e => setLimitsForm(f => ({ ...f, disk: Number(e.target.value) }))}
                        className="aw-input w-full rounded-xl px-4 py-2.5 text-sm"
                      />
                    </label>
                    <label className="flex flex-col gap-1.5 text-xs text-zinc-500">
                      Max servers per user
                      <input
                        type="number" min={0}
                        value={limitsForm.maxServers}
                        onChange={e => setLimitsForm(f => ({ ...f, maxServers: Number(e.target.value) }))}
                        className="aw-input w-full rounded-xl px-4 py-2.5 text-sm"
                      />
                    </label>
                    <label className="flex flex-col gap-1.5 text-xs text-zinc-500">
                      Minimum allowed port
                      <input
                        type="number" min={1} max={65535}
                        value={limitsForm.minPort}
                        onChange={e => setLimitsForm(f => ({ ...f, minPort: Number(e.target.value) }))}
                        className="aw-input w-full rounded-xl px-4 py-2.5 text-sm"
                      />
                    </label>
                    <div className="col-span-2 sm:col-span-3 flex items-center gap-3 mt-2">
                      <button disabled={isSavingLimits || isLoadingLimits} type="submit" className="aw-btn-primary px-6 py-2.5 rounded-xl font-semibold disabled:opacity-50">
                        Save Limits
                      </button>
                      {limitsMsg && (
                        <p className={`text-xs ${limitsMsg.type === "success" ? "text-emerald-400" : "text-red-400"}`}>
                          {limitsMsg.text}
                        </p>
                      )}
                    </div>
                  </form>
                </section>

                {/* ═══════════════════════════════════════
                    EGGS SECTION — ban/unban server software
                ═══════════════════════════════════════ */}
                <section id="eggs" className="scroll-mt-24 aw-glass p-6 md:p-8">
                  <h2 className="text-xl font-bold mb-2 flex items-center text-purple-200 relative z-10">
                    <Egg className="mr-3 text-purple-400 w-5 h-5" /> Eggs
                  </h2>
                  <p className="text-xs text-zinc-500 mb-6 relative z-10">
                    Ban server software so regular users can no longer select it when creating a server. Existing servers are unaffected.
                  </p>

                  <div className="relative z-10 flex flex-col gap-3">
                    {isLoadingEggs && <p className="text-xs text-zinc-500">Loading...</p>}
                    {["minecraft", "application"].map(category => {
                      const items = eggs.filter(e => e.category === category);
                      if (items.length === 0) return null;
                      return (
                        <div key={category} className="mb-2">
                          <h3 className="text-[10px] font-mono uppercase tracking-widest text-zinc-600 mb-2">
                            {category === "minecraft" ? "Minecraft Engines" : "Application Runtimes"}
                          </h3>
                          <div className="flex flex-col gap-2">
                            {items.map(egg => (
                              <div key={egg.id} className="aw-feature-row flex items-center justify-between gap-4 p-3.5 rounded-2xl">
                                <div className="flex items-center gap-2">
                                  {egg.disabled && <Ban className="w-3.5 h-3.5 text-red-400" />}
                                  <span className="font-semibold text-purple-200 text-sm">{egg.name}</span>
                                  {egg.disabled && <span className="text-[10px] font-mono uppercase text-red-400">banned</span>}
                                </div>
                                <label className="relative inline-flex items-center cursor-pointer">
                                  <input
                                    type="checkbox"
                                    checked={!egg.disabled}
                                    disabled={isSavingEggs}
                                    onChange={() => toggleEgg(egg.id, !egg.disabled)}
                                    className="sr-only peer aw-toggle"
                                  />
                                  <div className="aw-toggle-track w-11 h-6 bg-zinc-800 border border-purple-500/20 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-zinc-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all"></div>
                                </label>
                              </div>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </section>

              </div>
            </div>
          </main>
        </div>

        {selectedImage && (
          <ImageCropper
            imageSrc={selectedImage}
            onCropComplete={handleCropComplete}
            onCancel={() => { setSelectedImage(null); setCroppingType(null); }}
            aspectRatio={croppingType === "background" ? bgAspectRatio : 1}
            title={croppingType === "background" ? "Crop Background" : "Crop Logo"}
          />
        )}

        {(isProcessing || isUpdatingLogo || isSavingSettings || isCreatingUser || isUpdatingSystem) && <LoadingOverlay />}
      </div>
    </>
  );
}
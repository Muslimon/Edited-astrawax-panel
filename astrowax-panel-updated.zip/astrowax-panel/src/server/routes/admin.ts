import express, { Request, Response } from "express";
import crypto from "crypto";
import { readJSON, writeJSON } from "../services/db.js";
import { requireAdmin } from "../middleware/auth.js";
import { getLimitsConfig, setLimitsConfig } from "../utils/serverQuota.js";
import { getEggCatalog, setDisabledEggs } from "../utils/eggs.js";

const router = express.Router();

// Everything under /api/admin requires an admin or owner account.
router.use(requireAdmin);

// ═══════════════════════════════════════════
// ANNOUNCEMENTS — admin-only create/edit/delete
// Stored in .data/announcements.json
// ═══════════════════════════════════════════
type Announcement = {
  id: string;
  title: string;
  message: string;
  severity: "info" | "success" | "warning" | "critical";
  active: boolean;
  createdAt: string;
  updatedAt: string;
  createdBy: string;
  expiresAt: string | null;
};

const SEVERITIES = ["info", "success", "warning", "critical"];

router.get("/announcements", async (req: Request, res: Response) => {
  try {
    const list: Announcement[] = (await readJSON("announcements.json")) || [];
    list.sort((a, b) => (b.createdAt || "").localeCompare(a.createdAt || ""));
    res.json(list);
  } catch (err) {
    console.error("GET admin announcements error:", err);
    res.status(500).json({ error: "Failed to load announcements" });
  }
});

router.post("/announcements", async (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const { title, message, severity, active, expiresAt } = req.body || {};
    if (!title || !String(title).trim()) {
      res.status(400).json({ error: "Title is required" });
      return;
    }
    if (!message || !String(message).trim()) {
      res.status(400).json({ error: "Message is required" });
      return;
    }
    const list: Announcement[] = (await readJSON("announcements.json")) || [];
    const now = new Date().toISOString();
    const announcement: Announcement = {
      id: crypto.randomUUID(),
      title: String(title).trim().slice(0, 200),
      message: String(message).trim().slice(0, 2000),
      severity: SEVERITIES.includes(severity) ? severity : "info",
      active: active !== undefined ? !!active : true,
      createdAt: now,
      updatedAt: now,
      createdBy: user?.id || "unknown",
      expiresAt: expiresAt ? new Date(expiresAt).toISOString() : null,
    };
    list.push(announcement);
    await writeJSON("announcements.json", list);
    res.json(announcement);
  } catch (err) {
    console.error("POST admin announcements error:", err);
    res.status(500).json({ error: "Failed to create announcement" });
  }
});

router.put("/announcements/:id", async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const list: Announcement[] = (await readJSON("announcements.json")) || [];
    const idx = list.findIndex((a) => a.id === id);
    if (idx === -1) {
      res.status(404).json({ error: "Announcement not found" });
      return;
    }
    const { title, message, severity, active, expiresAt } = req.body || {};
    const current = list[idx];
    const updated: Announcement = {
      ...current,
      title: title !== undefined ? String(title).trim().slice(0, 200) : current.title,
      message: message !== undefined ? String(message).trim().slice(0, 2000) : current.message,
      severity: severity !== undefined && SEVERITIES.includes(severity) ? severity : current.severity,
      active: active !== undefined ? !!active : current.active,
      expiresAt: expiresAt !== undefined ? (expiresAt ? new Date(expiresAt).toISOString() : null) : current.expiresAt,
      updatedAt: new Date().toISOString(),
    };
    list[idx] = updated;
    await writeJSON("announcements.json", list);
    res.json(updated);
  } catch (err) {
    console.error("PUT admin announcements error:", err);
    res.status(500).json({ error: "Failed to update announcement" });
  }
});

router.delete("/announcements/:id", async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const list: Announcement[] = (await readJSON("announcements.json")) || [];
    const next = list.filter((a) => a.id !== id);
    if (next.length === list.length) {
      res.status(404).json({ error: "Announcement not found" });
      return;
    }
    await writeJSON("announcements.json", next);
    res.json({ success: true });
  } catch (err) {
    console.error("DELETE admin announcements error:", err);
    res.status(500).json({ error: "Failed to delete announcement" });
  }
});

// ═══════════════════════════════════════════
// SERVER LIMITS — admin-configurable plan/cap for regular users
// ═══════════════════════════════════════════
router.get("/limits", async (req: Request, res: Response) => {
  try {
    const limits = await getLimitsConfig();
    res.json(limits);
  } catch (err) {
    console.error("GET admin limits error:", err);
    res.status(500).json({ error: "Failed to load server limits" });
  }
});

router.put("/limits", async (req: Request, res: Response) => {
  try {
    const { ram, cpu, disk, maxServers, minPort } = req.body || {};
    const limits = await setLimitsConfig({ ram, cpu, disk, maxServers, minPort });
    res.json(limits);
  } catch (err) {
    console.error("PUT admin limits error:", err);
    res.status(500).json({ error: "Failed to update server limits" });
  }
});

// ═══════════════════════════════════════════
// EGGS — admin can ban/unban server software
// ═══════════════════════════════════════════
router.get("/eggs", async (req: Request, res: Response) => {
  try {
    const eggs = await getEggCatalog();
    res.json({ eggs });
  } catch (err) {
    console.error("GET admin eggs error:", err);
    res.status(500).json({ error: "Failed to load eggs" });
  }
});

router.put("/eggs", async (req: Request, res: Response) => {
  try {
    const { disabled } = req.body || {};
    const clean = await setDisabledEggs(Array.isArray(disabled) ? disabled : []);
    const eggs = await getEggCatalog();
    res.json({ eggs, disabled: clean });
  } catch (err) {
    console.error("PUT admin eggs error:", err);
    res.status(500).json({ error: "Failed to update eggs" });
  }
});

export default router;

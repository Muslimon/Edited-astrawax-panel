import express from "express";
import { readJSON } from "../services/db.js";
import { requireAuth } from "../middleware/auth.js";
import { getEggCatalog } from "../utils/eggs.js";

const router = express.Router();
import authRoutes from "./auth.js";
import serverRoutes from "./servers.js";
import systemRoutes from "./system.js";
import apiKeyRoutes from "./api-keys.js";
import nodeRoutes from "./nodes.js";
import adminRoutes from "./admin.js";

router.use("/auth", authRoutes);
router.use("/servers", serverRoutes);
router.use("/system", systemRoutes);
router.use("/admin/api-keys", apiKeyRoutes);
router.use("/admin", adminRoutes);
router.use("/nodes", nodeRoutes);

// ═══════════════════════════════════════════
// GET /api/announcements — active announcements for every logged-in user
// (admin CRUD for these lives at /api/admin/announcements)
// ═══════════════════════════════════════════
router.get("/announcements", requireAuth, async (req, res) => {
  try {
    const list = (await readJSON("announcements.json")) || [];
    const now = Date.now();
    const active = list.filter((a: any) => {
      if (!a.active) return false;
      if (a.expiresAt && new Date(a.expiresAt).getTime() < now) return false;
      return true;
    });
    active.sort((a: any, b: any) => (b.createdAt || "").localeCompare(a.createdAt || ""));
    res.json(active);
  } catch (err) {
    console.error("GET announcements error:", err);
    res.status(500).json({ error: "Failed to load announcements" });
  }
});

// ═══════════════════════════════════════════
// GET /api/eggs — server software catalog with admin-banned eggs flagged
// (used by the create-server page to hide/disable banned software)
// ═══════════════════════════════════════════
router.get("/eggs", requireAuth, async (req, res) => {
  try {
    const eggs = await getEggCatalog();
    res.json({ eggs });
  } catch (err) {
    console.error("GET eggs error:", err);
    res.status(500).json({ error: "Failed to load eggs" });
  }
});

router.get("/health", (req, res) => {
  res.json({
    status: "ok",
    panel: "AstroWax Panel",
    version: "1.80.0",
    timestamp: Date.now(),
    nodeEnv: process.env.NODE_ENV || "development"
  });
});

router.get("/settings", async (req, res) => {
  const settings = await readJSON("settings.json") || {};
  res.json({ 
    version: "1.80.0",
    panelName: settings.panelName || "AstroWax Panel",
    panelLogo: settings.panelLogo || "",
    panelBackgroundImage: settings.panelBackgroundImage || "",
    panelBackgroundBlur: settings.panelBackgroundBlur !== undefined ? settings.panelBackgroundBlur : 10,
    enablePlayit: settings.enablePlayit !== undefined ? settings.enablePlayit : false,
    enableTutorial: settings.enableTutorial !== undefined ? settings.enableTutorial : true,
    enableLoginAnimation: settings.enableLoginAnimation !== undefined ? settings.enableLoginAnimation : true,
    enableRegistration: settings.enableRegistration !== undefined ? settings.enableRegistration : true,
    theme: settings.theme || "red",
    enableGoogleLogin: settings.enableGoogleLogin !== undefined ? settings.enableGoogleLogin : false,
    firebaseApiKey: settings.firebaseApiKey || "",
    firebaseAuthDomain: settings.firebaseAuthDomain || "",
    firebaseProjectId: settings.firebaseProjectId || "",
    firebaseStorageBucket: settings.firebaseStorageBucket || "",
    firebaseMessagingSenderId: settings.firebaseMessagingSenderId || "",
    firebaseAppId: settings.firebaseAppId || "",
    defaultRuntime: settings.defaultRuntime || process.env.DEFAULT_RUNTIME || "docker",
    isDevPanel: (process.env.PANEL_TYPE === "dev" || process.env.PORT === "3000") && !process.env.FORCE_MAIN_PANEL,
    panelPort: process.env.PORT || "6767"
  });
});

export default router;

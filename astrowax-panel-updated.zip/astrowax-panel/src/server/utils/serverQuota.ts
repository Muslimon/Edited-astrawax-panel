// ============================================
// Regular-user server plan & quota
// Single source of truth for what a non-admin user may create.
// Admin/owner accounts are never restricted by anything in this file.
// ============================================

/** Fixed resources for every server a regular user creates. */
export const USER_PLAN = {
  ram: 4,   // GB
  cpu: 150, // percent (100 = one core)
  disk: 10, // GB
} as const;

/** Maximum number of servers a regular user may own. */
export const USER_MAX_SERVERS = 2;

/** Ports below this are reserved for system services; regular users can't pick them. */
export const USER_MIN_PORT = 1024;
export const MAX_PORT = 65535;

export const isPrivileged = (user: any): boolean =>
  user?.role === "admin" || user?.role === "owner";

export const countOwnedServers = (servers: any[], userId: string): number =>
  (Array.isArray(servers) ? servers : []).filter((s) => s?.owner === userId).length;

export interface QuotaInfo {
  isAdmin: boolean;
  /** null = unlimited (admin/owner) */
  maxServers: number | null;
  used: number;
  /** null = unlimited (admin/owner) */
  remaining: number | null;
  /** null for admin/owner, who choose resources freely */
  plan: { ram: number; cpu: number; disk: number } | null;
}

export const getQuota = (user: any, servers: any[]): QuotaInfo => {
  if (isPrivileged(user)) {
    return {
      isAdmin: true,
      maxServers: null,
      used: countOwnedServers(servers, user?.id),
      remaining: null,
      plan: null,
    };
  }
  const used = countOwnedServers(servers, user?.id);
  return {
    isAdmin: false,
    maxServers: USER_MAX_SERVERS,
    used,
    remaining: Math.max(0, USER_MAX_SERVERS - used),
    plan: USER_PLAN,
  };
};

/** Returns an error message if the user may not create another server, otherwise null. */
export const checkCreateAllowed = (user: any, servers: any[]): string | null => {
  const q = getQuota(user, servers);
  if (q.isAdmin) return null;
  if ((q.remaining ?? 0) <= 0) {
    return `Server limit reached (${q.used}/${q.maxServers}). You cannot create more servers.`;
  }
  return null;
};

/** Returns an error message if a regular user picked a disallowed port, otherwise null. */
export const checkUserPort = (port: unknown): string | null => {
  const p = Number(port);
  if (!Number.isInteger(p) || p < USER_MIN_PORT || p > MAX_PORT) {
    return `Port must be a whole number between ${USER_MIN_PORT} and ${MAX_PORT}.`;
  }
  return null;
};

// ============================================
// Admin-configurable overrides (persisted in settings.json under "serverLimits")
// Everything above stays as the hardcoded fallback/default and keeps working
// unmodified (existing tests rely on it). Routes/controllers that should
// respect admin-configured limits use the *Async helpers below instead.
// ============================================
import { readJSON, writeJSON } from "../services/db.js";

export interface LimitsConfig {
  ram: number;
  cpu: number;
  disk: number;
  maxServers: number;
  minPort: number;
}

/** Reads the admin-configured limits, falling back to the hardcoded defaults above. */
export const getLimitsConfig = async (): Promise<LimitsConfig> => {
  const settings = (await readJSON("settings.json")) || {};
  const cfg = settings.serverLimits || {};
  return {
    ram: Number(cfg.ram) > 0 ? Number(cfg.ram) : USER_PLAN.ram,
    cpu: Number(cfg.cpu) > 0 ? Number(cfg.cpu) : USER_PLAN.cpu,
    disk: Number(cfg.disk) > 0 ? Number(cfg.disk) : USER_PLAN.disk,
    maxServers:
      Number.isInteger(cfg.maxServers) && cfg.maxServers >= 0
        ? cfg.maxServers
        : USER_MAX_SERVERS,
    minPort:
      Number.isInteger(cfg.minPort) && cfg.minPort >= 1 && cfg.minPort <= MAX_PORT
        ? cfg.minPort
        : USER_MIN_PORT,
  };
};

/** Persists a partial update to the admin-configured limits. Returns the merged config. */
export const setLimitsConfig = async (partial: Partial<LimitsConfig>): Promise<LimitsConfig> => {
  const settings = (await readJSON("settings.json")) || {};
  const current = settings.serverLimits || {};
  const merged: any = { ...current };

  if (partial.ram !== undefined) merged.ram = Math.max(1, Math.min(1024, Number(partial.ram) || USER_PLAN.ram));
  if (partial.cpu !== undefined) merged.cpu = Math.max(10, Math.min(3200, Number(partial.cpu) || USER_PLAN.cpu));
  if (partial.disk !== undefined) merged.disk = Math.max(1, Math.min(4096, Number(partial.disk) || USER_PLAN.disk));
  if (partial.maxServers !== undefined) {
    const n = parseInt(String(partial.maxServers), 10);
    merged.maxServers = Number.isFinite(n) && n >= 0 ? n : USER_MAX_SERVERS;
  }
  if (partial.minPort !== undefined) {
    const n = parseInt(String(partial.minPort), 10);
    merged.minPort = Number.isFinite(n) ? Math.max(1, Math.min(MAX_PORT, n)) : USER_MIN_PORT;
  }

  settings.serverLimits = merged;
  await writeJSON("settings.json", settings);
  return getLimitsConfig();
};

/** Same shape as getQuota, but uses the admin-configured limits instead of the hardcoded plan. */
export const getQuotaAsync = async (user: any, servers: any[]): Promise<QuotaInfo> => {
  const used = countOwnedServers(servers, user?.id);
  if (isPrivileged(user)) {
    return { isAdmin: true, maxServers: null, used, remaining: null, plan: null };
  }
  const limits = await getLimitsConfig();
  return {
    isAdmin: false,
    maxServers: limits.maxServers,
    used,
    remaining: Math.max(0, limits.maxServers - used),
    plan: { ram: limits.ram, cpu: limits.cpu, disk: limits.disk },
  };
};

/** Same as checkCreateAllowed, but respects the admin-configured server cap. */
export const checkCreateAllowedAsync = async (user: any, servers: any[]): Promise<string | null> => {
  const q = await getQuotaAsync(user, servers);
  if (q.isAdmin) return null;
  if ((q.remaining ?? 0) <= 0) {
    return `Server limit reached (${q.used}/${q.maxServers}). You cannot create more servers.`;
  }
  return null;
};

/** Same as checkUserPort, but respects the admin-configured minimum port. */
export const checkUserPortAsync = async (port: unknown): Promise<string | null> => {
  const limits = await getLimitsConfig();
  const p = Number(port);
  if (!Number.isInteger(p) || p < limits.minPort || p > MAX_PORT) {
    return `Port must be a whole number between ${limits.minPort} and ${MAX_PORT}.`;
  }
  return null;
};

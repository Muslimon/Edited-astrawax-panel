import { readJSON, writeJSON } from "../services/db.js";

// ============================================
// Egg (server software) catalog + admin ban list
// Mirrors the software list shown on the Create Server page
// (src/pages/CreateServer.tsx: MINECRAFT_SOFTWARE + APPLICATION_SOFTWARE).
// Admins can disable ("ban") any egg here; disabled eggs are hidden from
// regular users on the create-server form and rejected server-side.
// ============================================

export interface EggDefinition {
  id: string;
  name: string;
  category: "minecraft" | "application";
}

export const EGG_CATALOG: EggDefinition[] = [
  { id: "paper", name: "Paper", category: "minecraft" },
  { id: "spigot", name: "Spigot", category: "minecraft" },
  { id: "fabric", name: "Fabric", category: "minecraft" },
  { id: "forge", name: "Forge", category: "minecraft" },
  { id: "bungeecord", name: "BungeeCord", category: "minecraft" },
  { id: "velocity", name: "Velocity", category: "minecraft" },
  { id: "nodejs", name: "Node.js", category: "application" },
  { id: "python", name: "Python", category: "application" },
];

const VALID_IDS = new Set(EGG_CATALOG.map((e) => e.id));

export const getDisabledEggs = async (): Promise<string[]> => {
  const settings = (await readJSON("settings.json")) || {};
  const list = Array.isArray(settings.disabledEggs) ? settings.disabledEggs : [];
  return list.filter((id: any) => VALID_IDS.has(String(id).toLowerCase()));
};

/** Persists the full set of disabled egg ids. Unknown ids are silently dropped. */
export const setDisabledEggs = async (ids: string[]): Promise<string[]> => {
  const settings = (await readJSON("settings.json")) || {};
  const clean = Array.from(
    new Set((Array.isArray(ids) ? ids : []).map((id) => String(id).toLowerCase()).filter((id) => VALID_IDS.has(id)))
  );
  settings.disabledEggs = clean;
  await writeJSON("settings.json", settings);
  return clean;
};

/** Full catalog annotated with each egg's current enabled/disabled state. */
export const getEggCatalog = async () => {
  const disabled = await getDisabledEggs();
  return EGG_CATALOG.map((egg) => ({ ...egg, disabled: disabled.includes(egg.id) }));
};

export const isEggDisabled = async (id: unknown): Promise<boolean> => {
  if (!id) return false;
  const disabled = await getDisabledEggs();
  return disabled.includes(String(id).toLowerCase());
};

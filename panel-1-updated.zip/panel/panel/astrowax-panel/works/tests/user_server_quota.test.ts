import assert from "assert";
import {
  USER_PLAN,
  USER_MAX_SERVERS,
  getQuota,
  checkCreateAllowed,
  checkUserPort,
  isPrivileged,
  countOwnedServers,
} from "../../src/server/utils/serverQuota.js";

console.log("▶ Running User Server Quota Test...");

const user = { id: "user-1", role: "user" };
const other = { id: "user-2", role: "user" };
const admin = { id: "admin-1", role: "admin" };
const owner = { id: "owner-1", role: "owner" };

const srv = (ownerId: string, n: number) => ({ id: `s${n}`, owner: ownerId });

// Plan is exactly what was requested
assert.deepStrictEqual({ ...USER_PLAN }, { ram: 4, cpu: 150, disk: 10 }, "plan = 4GB RAM / 150% CPU / 10GB disk");
assert.strictEqual(USER_MAX_SERVERS, 2, "cap = 2 servers per user");

// Roles
assert.strictEqual(isPrivileged(admin), true);
assert.strictEqual(isPrivileged(owner), true);
assert.strictEqual(isPrivileged(user), false);
assert.strictEqual(isPrivileged(undefined), false);

// 0 and 1 servers: allowed
assert.strictEqual(checkCreateAllowed(user, []), null, "0 servers → allowed");
assert.strictEqual(checkCreateAllowed(user, [srv("user-1", 1)]), null, "1 server → allowed");

// 2 servers: blocked
const two = [srv("user-1", 1), srv("user-1", 2)];
assert.match(checkCreateAllowed(user, two) as string, /limit reached \(2\/2\)/i, "2 servers → blocked");

// Someone else's servers don't count against the user
const mixed = [srv("user-2", 1), srv("user-2", 2), srv("user-2", 3), srv("user-1", 4)];
assert.strictEqual(countOwnedServers(mixed, "user-1"), 1);
assert.strictEqual(checkCreateAllowed(user, mixed), null, "other users' servers are not counted");
assert.match(checkCreateAllowed(other, mixed) as string, /limit reached/i, "user-2 has 3 → blocked");

// Admin / owner are never limited, whatever they own
const many = Array.from({ length: 50 }, (_, i) => srv("admin-1", i));
assert.strictEqual(checkCreateAllowed(admin, many), null, "admin unlimited");
assert.strictEqual(checkCreateAllowed(owner, many), null, "owner unlimited");

// Quota payload for the UI
const q = getQuota(user, [srv("user-1", 1)]);
assert.deepStrictEqual(
  { isAdmin: q.isAdmin, maxServers: q.maxServers, used: q.used, remaining: q.remaining },
  { isAdmin: false, maxServers: 2, used: 1, remaining: 1 },
);
assert.deepStrictEqual({ ...q.plan }, { ram: 4, cpu: 150, disk: 10 });
const qa = getQuota(admin, []);
assert.strictEqual(qa.isAdmin, true);
assert.strictEqual(qa.maxServers, null);
assert.strictEqual(qa.plan, null);

// A server list that isn't an array must not crash the check
assert.strictEqual(checkCreateAllowed(user, null as any), null);

// Ports regular users may pick
assert.strictEqual(checkUserPort(25565), null);
assert.strictEqual(checkUserPort("25566"), null, "numeric strings are fine");
assert.strictEqual(checkUserPort(1024), null);
assert.strictEqual(checkUserPort(65535), null);
assert.ok(checkUserPort(22), "reserved port rejected");
assert.ok(checkUserPort(80), "reserved port rejected");
assert.ok(checkUserPort(1023), "just below the range rejected");
assert.ok(checkUserPort(65536), "above range rejected");
assert.ok(checkUserPort(25565.5), "non-integer rejected");
assert.ok(checkUserPort("abc"), "garbage rejected");
assert.ok(checkUserPort(undefined), "missing rejected");

console.log("✓ User Server Quota Test PASSED successfully.");

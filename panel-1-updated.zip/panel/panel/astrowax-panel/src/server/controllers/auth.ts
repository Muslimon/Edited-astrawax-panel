import { Request, Response } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { readJSON, writeJSON } from "../services/db.js";

const JWT_SECRET = process.env.JWT_SECRET || "jtg-panel-super-secret";

// ═══════════════════════════════════════════════════════════════
// REGISTER — First user becomes OWNER
// ═══════════════════════════════════════════════════════════════
export const register = async (req: Request, res: Response) => {
  try {
    const settings = (await readJSON("settings.json")) || {};
    if (settings.enableRegistration === false) {
      res.status(403).json({ error: "User registration is currently disabled by administrator." });
      return;
    }

    const { username, password, confirmPassword } = req.body;

    if (!username || !password || !confirmPassword) {
      res.status(400).json({ error: "Username, password, and confirm password are required" });
      return;
    }

    const cleanUsername = String(username).trim();
    if (cleanUsername.length < 3) {
      res.status(400).json({ error: "Username must be at least 3 characters" });
      return;
    }

    if (cleanUsername.length > 32) {
      res.status(400).json({ error: "Username must be 32 characters or less" });
      return;
    }

    if (password.length < 6) {
      res.status(400).json({ error: "Password must be at least 6 characters" });
      return;
    }

    if (password !== confirmPassword) {
      res.status(400).json({ error: "Passwords do not match" });
      return;
    }

    const users = (await readJSON("users.json")) || [];
    const existingUser = users.find(
      (u: any) => u.username && u.username.toLowerCase() === cleanUsername.toLowerCase()
    );

    if (existingUser) {
      res.status(400).json({ error: "Username is already taken" });
      return;
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    // ✅ FIRST USER → OWNER, everyone else → USER
    const isFirstUser = users.length === 0;
    const assignedRole = isFirstUser ? "owner" : "user";

    const newUser = {
      id: "user-" + Date.now() + "-" + Math.random().toString(36).substring(2, 7),
      username: cleanUsername,
      password: hashedPassword,
      role: assignedRole,
      passwordVersion: 0,
      createdAt: new Date().toISOString(),
      lastLogin: null,
    };

    users.push(newUser);
    await writeJSON("users.json", users);

    console.log(`✅ Registered "${cleanUsername}" → role=${assignedRole}`);

    res.status(201).json({
      message: "User registered successfully",
      user: { id: newUser.id, username: newUser.username, role: newUser.role },
    });
  } catch (err: any) {
    console.error("Register error:", err);
    res.status(500).json({ error: "Registration failed" });
  }
};

// ═══════════════════════════════════════════════════════════════
// LOGIN — Strict validation, no auto-create
// ═══════════════════════════════════════════════════════════════
export const login = async (req: Request, res: Response) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      res.status(400).json({ error: "Username and password required" });
      return;
    }

    const cleanUsername = String(username).trim();
    const users = (await readJSON("users.json")) || [];

    console.log(`🔐 Login attempt: "${cleanUsername}" | total users=${users.length}`);

    // Case-insensitive lookup
    const user = users.find(
      (u: any) => u.username && u.username.toLowerCase() === cleanUsername.toLowerCase()
    );

    // ✅ User MUST exist — do NOT auto-create
    if (!user) {
      console.log(`❌ User "${cleanUsername}" not found`);
      res.status(401).json({ error: "Invalid username or password" });
      return;
    }

    // Google-only account
    if (!user.password) {
      res.status(401).json({
        error: "This account uses Google Sign-In. Please log in with Google.",
      });
      return;
    }

    // Verify password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      console.log(`❌ Wrong password for "${cleanUsername}"`);
      res.status(401).json({ error: "Invalid username or password" });
      return;
    }

    // Update lastLogin
    user.lastLogin = new Date().toISOString();
    await writeJSON("users.json", users);

    // ✅ Fallback role = "user" (not admin)
    const role = user.role || "user";

    console.log(`✅ Login success: "${user.username}" (${role})`);

    const token = jwt.sign(
      { id: user.id, username: user.username, role, passwordVersion: user.passwordVersion || 0 },
      JWT_SECRET,
      { expiresIn: "7d" }
    );

    res.json({
      token,
      user: { id: user.id, username: user.username, role },
    });
  } catch (err: any) {
    console.error("Login error:", err);
    res.status(500).json({ error: "Login failed" });
  }
};

// ═══════════════════════════════════════════════════════════════
// LOGOUT
// ═══════════════════════════════════════════════════════════════
export const logout = (req: Request, res: Response) => {
  res.json({ message: "Logged out" });
};

// ═══════════════════════════════════════════════════════════════
// GET ME
// ═══════════════════════════════════════════════════════════════
export const getMe = async (req: Request, res: Response) => {
  try {
    const reqUser = (req as any).user;
    if (reqUser && reqUser.id !== "temp-admin") {
      const users = (await readJSON("users.json")) || [];
      const dbUser = users.find((u: any) => u.id === reqUser.id);
      if (dbUser) {
        return res.json({
          user: {
            ...reqUser,
            googleId: dbUser.googleId || null,
            isGoogleUser: !!(dbUser.googleId || !dbUser.password),
          },
        });
      }
    }
    res.json({ user: reqUser });
  } catch (err: any) {
    console.error("getMe error:", err);
    res.status(500).json({ error: "Failed to load user" });
  }
};

// ═══════════════════════════════════════════════════════════════
// GET USERS
// ═══════════════════════════════════════════════════════════════
export const getUsers = async (req: Request, res: Response) => {
  try {
    const users = (await readJSON("users.json")) || [];
    res.json(
      users.map((u: any) => ({
        id: u.id,
        username: u.username,
        role: u.role,
        isGoogleUser: !!u.googleId,
      }))
    );
  } catch (err: any) {
    console.error("getUsers error:", err);
    res.status(500).json({ error: "Failed to load users" });
  }
};

// ═══════════════════════════════════════════════════════════════
// CHANGE USERNAME
// ═══════════════════════════════════════════════════════════════
export const changeUsername = async (req: Request, res: Response) => {
  try {
    const reqUser = (req as any).user;
    const { newUsername } = req.body;

    if (!newUsername || typeof newUsername !== "string" || newUsername.trim().length < 3) {
      return res.status(400).json({ error: "Username must be at least 3 characters long." });
    }

    const cleanUsername = newUsername.trim();

    if (reqUser.id === "temp-admin") {
      return res.status(400).json({ error: "Cannot change username of default admin account." });
    }

    const users = (await readJSON("users.json")) || [];
    const userIndex = users.findIndex((u: any) => u.id === reqUser.id);

    if (userIndex === -1) {
      return res.status(404).json({ error: "User not found" });
    }

    if (!users[userIndex].googleId) {
      return res.status(400).json({
        error: "Username change is only available for Google authenticated accounts.",
      });
    }

    const existingUser = users.find(
      (u: any) => u.id !== reqUser.id && u.username && u.username.toLowerCase() === cleanUsername.toLowerCase()
    );
    if (existingUser) {
      return res.status(400).json({ error: `Username '${cleanUsername}' is already taken.` });
    }

    users[userIndex].username = cleanUsername;
    await writeJSON("users.json", users);

    res.json({ success: true, username: cleanUsername });
  } catch (err: any) {
    console.error("changeUsername error:", err);
    res.status(500).json({ error: "Failed to change username" });
  }
};

// ═══════════════════════════════════════════════════════════════
// CHANGE PASSWORD
// ═══════════════════════════════════════════════════════════════
export const changePassword = async (req: Request, res: Response) => {
  try {
    const reqUser = (req as any).user;
    const { oldPassword, newPassword } = req.body;

    if (reqUser.id === "temp-admin") {
      return res.status(400).json({
        error: "Cannot change password of default admin account. Create a new admin user instead.",
      });
    }

    const users = (await readJSON("users.json")) || [];
    const userIndex = users.findIndex((u: any) => u.id === reqUser.id);

    if (userIndex === -1) {
      return res.status(404).json({ error: "User not found" });
    }

    if (users[userIndex].googleId || !users[userIndex].password) {
      return res.status(400).json({ error: "Password change is disabled for Google Auth accounts." });
    }

    if (!newPassword || newPassword.length < 8) {
      return res.status(400).json({ error: "New password must be at least 8 characters" });
    }

    const isMatch = await bcrypt.compare(oldPassword || "", users[userIndex].password);
    if (!isMatch) {
      return res.status(401).json({ error: "Incorrect old password" });
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);

    users[userIndex].password = hashedPassword;
    users[userIndex].passwordVersion = (users[userIndex].passwordVersion || 0) + 1;
    await writeJSON("users.json", users);

    res.json({ success: true });
  } catch (err: any) {
    console.error("changePassword error:", err);
    res.status(500).json({ error: "Failed to change password" });
  }
};

// ═══════════════════════════════════════════════════════════════
// GOOGLE LOGIN — First user becomes OWNER
// ═══════════════════════════════════════════════════════════════
export const googleLogin = async (req: Request, res: Response) => {
  try {
    const { email, googleId, name, photoURL } = req.body;

    if (!email) {
      res.status(400).json({ error: "Google email is required" });
      return;
    }

    const settings = (await readJSON("settings.json")) || {};
    if (settings.enableGoogleLogin === false) {
      res.status(403).json({ error: "Google Login is disabled on this panel." });
      return;
    }

    const emailPrefix = String(email).split("@")[0].replace(/[^a-zA-Z0-9_.]/g, "");
    const baseUsername = emailPrefix || "user";

    const users = (await readJSON("users.json")) || [];
    let user = users.find(
      (u: any) =>
        (u.email && u.email.toLowerCase() === String(email).toLowerCase()) ||
        (u.googleId && u.googleId === googleId) ||
        (u.username && u.username.toLowerCase() === baseUsername.toLowerCase())
    );

    if (!user) {
      // ✅ First user in the whole system → OWNER
      const isFirstUser = users.length === 0;
      const role = isFirstUser ? "owner" : "user";

      user = {
        id: "google-user-" + Date.now() + "-" + Math.random().toString(36).substring(2, 7),
        username: baseUsername,
        email,
        googleId,
        role,
        avatar: photoURL || "",
        passwordVersion: 0,
        createdAt: new Date().toISOString(),
        lastLogin: new Date().toISOString(),
      };

      users.push(user);
      await writeJSON("users.json", users);
      console.log(`✅ Google first user "${baseUsername}" → ${role}`);
    } else {
      let updated = false;
      if (!user.email) { user.email = email; updated = true; }
      if (!user.googleId) { user.googleId = googleId; updated = true; }
      if (photoURL && !user.avatar) { user.avatar = photoURL; updated = true; }
      user.lastLogin = new Date().toISOString();
      updated = true;

      if (updated) {
        await writeJSON("users.json", users);
      }
    }

    // ✅ Fallback role = "user" (not admin)
    const role = user.role || "user";
    const token = jwt.sign(
      { id: user.id, username: user.username, role, passwordVersion: user.passwordVersion || 0 },
      JWT_SECRET,
      { expiresIn: "7d" }
    );

    res.json({
      token,
      user: {
        id: user.id,
        username: user.username,
        role,
        email: user.email,
        avatar: user.avatar,
        googleId: user.googleId,
        isGoogleUser: true,
      },
    });
  } catch (err: any) {
    console.error("Google login error:", err);
    res.status(500).json({ error: "Google login failed" });
  }
};
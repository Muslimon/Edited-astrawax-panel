// ============================================
// Regular-user server plan & quota
// Single source of truth for what a non-admin user may create.
// Admin/owner accounts are never restricted by anything in this file.
// ============================================

/** Fixed resources for every server a regular user creates. */
export const USER_PLAN = {
  ram: 4,   // GB
  cpu: 150, // percent (100 = one core)
  disk: 10, // GB
} as const;

/** Maximum number of servers a regular user may own. */
export const USER_MAX_SERVERS = 2;

/** Ports below this are reserved for system services; regular users can't pick them. */
export const USER_MIN_PORT = 1024;
export const MAX_PORT = 65535;

export const isPrivileged = (user: any): boolean =>
  user?.role === "admin" || user?.role === "owner";

export const countOwnedServers = (servers: any[], userId: string): number =>
  (Array.isArray(servers) ? servers : []).filter((s) => s?.owner === userId).length;

export interface QuotaInfo {
  isAdmin: boolean;
  /** null = unlimited (admin/owner) */
  maxServers: number | null;
  used: number;
  /** null = unlimited (admin/owner) */
  remaining: number | null;
  /** null for admin/owner, who choose resources freely */
  plan: typeof USER_PLAN | null;
}

export const getQuota = (user: any, servers: any[]): QuotaInfo => {
  if (isPrivileged(user)) {
    return {
      isAdmin: true,
      maxServers: null,
      used: countOwnedServers(servers, user?.id),
      remaining: null,
      plan: null,
    };
  }
  const used = countOwnedServers(servers, user?.id);
  return {
    isAdmin: false,
    maxServers: USER_MAX_SERVERS,
    used,
    remaining: Math.max(0, USER_MAX_SERVERS - used),
    plan: USER_PLAN,
  };
};

/** Returns an error message if the user may not create another server, otherwise null. */
export const checkCreateAllowed = (user: any, servers: any[]): string | null => {
  const q = getQuota(user, servers);
  if (q.isAdmin) return null;
  if ((q.remaining ?? 0) <= 0) {
    return `Server limit reached (${q.used}/${q.maxServers}). You cannot create more servers.`;
  }
  return null;
};

/** Returns an error message if a regular user picked a disallowed port, otherwise null. */
export const checkUserPort = (port: unknown): string | null => {
  const p = Number(port);
  if (!Number.isInteger(p) || p < USER_MIN_PORT || p > MAX_PORT) {
    return `Port must be a whole number between ${USER_MIN_PORT} and ${MAX_PORT}.`;
  }
  return null;
};
